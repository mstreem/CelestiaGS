#pragma once
#include "pch.h"
#include "Looting.h"
#include "Vehicles.h"
#include "Misc.h"
#include "Globals.h"
#include "Abilities.h"

class GameMode
{
	static inline bool (*ReadyToStartMatchOG)(AFortGameModeAthena *);
	static bool ReadyToStartMatchHook(AFortGameModeAthena *GM)
	{
		ReadyToStartMatchOG(GM);
		static bool bSetupPlaylist = false;
		auto GS = AFortGameStateAthena::Get();
		if (!bSetupPlaylist)
		{
			bSetupPlaylist = true;
			SetConsoleTitleA("Atlas | Setting up");
			GM->WarmupRequiredPlayerCount = 1;

			auto Playlist = Utils::FindObject<UFortPlaylistAthena>(Globals::PlaylistName.data());

			GS->CurrentPlaylistInfo.BasePlaylist = Playlist;
			GS->CurrentPlaylistInfo.OverridePlaylist = Playlist;
			GS->CurrentPlaylistInfo.PlaylistReplicationKey++;
			GS->CurrentPlaylistInfo.MarkArrayDirty();
			GS->OnRep_CurrentPlaylistInfo();

			GM->bAlwaysDBNO = Playlist->MaxSquadSize > 1;

			GS->CurrentPlaylistId = Playlist->PlaylistId;
			GS->OnRep_CurrentPlaylistId();

			GM->CurrentPlaylistName = Playlist->PlaylistName;
			GM->CurrentPlaylistId = Playlist->PlaylistId;

			auto Session = Utils::SpawnActor<AFortGameSessionDedicatedAthena>(FVector{0, 0, -99999}, {});
			Session->SessionName = UKismetStringLibrary::Conv_StringToName(L"GameSession");
			Session->MaxPlayers = Playlist->MaxPlayers;
			GM->GameSession = Session;
			GM->GameSessionClass = Session->Class;
			GM->FortGameSession = Session;
			GM->GameModeSessionString = L"GameSession";

			GS->CachedSafeZoneStartUp = Playlist->SafeZoneStartUp;
			GS->AirCraftBehavior = Playlist->AirCraftBehavior;

			if (!Playlist->bIsDefaultPlaylist)
			{
				for (auto &Level : Playlist->AdditionalLevelsServerOnly)
				{
					ULevelStreamingDynamic::LoadLevelInstanceBySoftObjectPtr(UWorld::Get(), Level, FVector{}, FRotator{}, nullptr, FString());
					GS->AdditionalPlaylistLevelsStreamed.Add({Level.ObjectID.AssetPathName, true});
				}
				for (auto &Level : Playlist->AdditionalLevels)
				{
					ULevelStreamingDynamic::LoadLevelInstanceBySoftObjectPtr(UWorld::Get(), Level, FVector{}, FRotator{}, nullptr, FString());
					GS->AdditionalPlaylistLevelsStreamed.Add({Level.ObjectID.AssetPathName, false});
				}
			}
		}

		static bool hitContainers = false;
		if (!Globals::bCreative)
		{
			if (!hitContainers)
			{
				auto Containers = Utils::GetAll<ABuildingContainer>();
				auto ContainerNum = Containers.Num();
				Containers.Free();
				if (ContainerNum != 5287 && ContainerNum != 5178 && ContainerNum != 5170 && ContainerNum != 5171 && ContainerNum != 5214 && ContainerNum != 5257)
					return false; // wait for map to fully load
				hitContainers = true;
			}
		}
		else
		{
			static bool bCreativeFree = false;
			if (!bCreativeFree)
			{
				auto CreativeStarts = Utils::GetAll<AFortPlayerStartCreative>();
				auto CreativeNum = CreativeStarts.Num();
				CreativeStarts.Free();
				if (CreativeNum == 0)
					return false;
				bCreativeFree = true;
			}
		}

		static bool bListening = false;
		if (!bListening)
		{
			bListening = true;

			using CreateNetDriverType = UNetDriver *(*)(UEngine *, UWorld *, FName);
			using InitListenType = bool (*)(UNetDriver *, UWorld *, FURL &, bool, FString &);
			using SetWorldType = void (*)(UNetDriver *, UWorld *);

			auto GND = UKismetStringLibrary::Conv_StringToName(L"GameNetDriver");
			auto NetDriver = ((CreateNetDriverType)CreateNetDriver)(UEngine::GetEngine(), UWorld::Get(), GND);
			NetDriver->World = UWorld::Get();
			NetDriver->NetDriverName = GND;

			UWorld::Get()->NetDriver = NetDriver;
			for (auto &Collection : UWorld::Get()->LevelCollections)
				Collection.NetDriver = NetDriver;

			if (!Globals::bCreative)
			{
				auto RebootVans = Utils::GetAll<ABuildingGameplayActorSpawnMachine>();
				auto PlayerStarts = Utils::GetAll<AFortPlayerStart>();
				for (auto &Van : RebootVans)
				{
					AFortPlayerStart *ClosestStart = nullptr;
					float ClosestDistance = 0.f;
					for (auto &Start : PlayerStarts)
					{
						auto Distance = Start->K2_GetActorLocation().GetDistanceTo(Van->K2_GetActorLocation());
						if (ClosestStart == nullptr || Distance < ClosestDistance)
						{
							ClosestDistance = Distance;
							ClosestStart = Start;
						}
					}
					Van->ResurrectLocation = ClosestStart;
				}
				PlayerStarts.Free();
				RebootVans.Free();

				Looting::bScuffed = true;
				for (auto &AmmoBoxType : GS->MapInfo->AmmoBoxSpawnInfos)
				{
					float AmmoSpawnMin, AmmoSpawnMax;
					UDataTableFunctionLibrary::GetDefaultObj()->EvaluateCurveTableRow(AmmoBoxType.AmmoBoxMinSpawnPercent.Curve.CurveTable, AmmoBoxType.AmmoBoxMinSpawnPercent.Curve.RowName, (float)0, nullptr, &AmmoSpawnMin, FString());
					UDataTableFunctionLibrary::GetDefaultObj()->EvaluateCurveTableRow(AmmoBoxType.AmmoBoxMaxSpawnPercent.Curve.CurveTable, AmmoBoxType.AmmoBoxMaxSpawnPercent.Curve.RowName, (float)0, nullptr, &AmmoSpawnMax, FString());

					auto AmmoBoxes = Utils::GetAll(AmmoBoxType.AmmoBoxClass);
					auto NumToWipe = (int)(AmmoSpawnMax - AmmoSpawnMin) == 0 ? 0 : AmmoBoxes.Num() * (rand() % (int)(AmmoSpawnMax - AmmoSpawnMin));
					NumToWipe += AmmoBoxes.Num() * (100 - (int)AmmoSpawnMax) / 100;

					for (int i = 0; i < NumToWipe; i++)
					{
						AmmoBoxes[rand() % AmmoBoxes.Num()]->K2_DestroyActor();
					}
					AmmoBoxes.Free();
				}
				for (auto &ChestType : GS->MapInfo->TreasureChestSpawnInfos)
				{
					float ChestSpawnMin, ChestSpawnMax;
					UDataTableFunctionLibrary::GetDefaultObj()->EvaluateCurveTableRow(ChestType.TreasureChestMinSpawnPercent.Curve.CurveTable, ChestType.TreasureChestMinSpawnPercent.Curve.RowName, (float)0, nullptr, &ChestSpawnMin, FString());
					UDataTableFunctionLibrary::GetDefaultObj()->EvaluateCurveTableRow(ChestType.TreasureChestMinSpawnPercent.Curve.CurveTable, ChestType.TreasureChestMinSpawnPercent.Curve.RowName, (float)0, nullptr, &ChestSpawnMax, FString());

					auto Chests = Utils::GetAll(ChestType.TreasureChestClass);
					auto NumToWipe = (int)(ChestSpawnMax - ChestSpawnMin) == 0 ? 0 : Chests.Num() * (rand() % (int)(ChestSpawnMax - ChestSpawnMin));
					NumToWipe += Chests.Num() * (100 - (int)ChestSpawnMax) / 100;

					for (int i = 0; i < NumToWipe; i++)
					{
						Chests[rand() % Chests.Num()]->K2_DestroyActor();
					}
					Chests.Free();
				}
				Looting::bScuffed = false;

				Looting::SpawnFloorLootForContainer(Utils::FindObject<UBlueprintGeneratedClass>("/Game/Athena/Environments/Blueprints/Tiered_Athena_FloorLoot_Warmup.Tiered_Athena_FloorLoot_Warmup_C"));
				Looting::SpawnFloorLootForContainer(Utils::FindObject<UBlueprintGeneratedClass>("/Game/Athena/Environments/Blueprints/Tiered_Athena_FloorLoot_01.Tiered_Athena_FloorLoot_01_C"));

				if (GS->CurrentPlaylistInfo.BasePlaylist->bIsDefaultPlaylist)
				{
					UFortServerBotManagerAthena *BotManager = (UFortServerBotManagerAthena *)UGameplayStatics::SpawnObject(UFortServerBotManagerAthena::StaticClass(), GM);
					GM->ServerBotManager = BotManager;
					BotManager->CachedGameState = GS;
					BotManager->CachedGameMode = GM;

					auto BotMutator = Utils::SpawnActor<AFortAthenaMutator_Bots>({0, 0, -99999}, {});
					BotManager->CachedBotMutator = BotMutator;
					BotMutator->CachedGameMode = GM;
					BotMutator->CachedGameState = GS;
					GM->MutatorListComponent->Mutators.Add(BotMutator);

					AAthenaAIDirector *Director = Utils::SpawnActor<AAthenaAIDirector>({0, 0, -99999}, {});
					GM->AIDirector = Director;
					Director->Activate();

					GM->AIGoalManager = Utils::SpawnActor<AFortAIGoalManager>({0, 0, -99999}, {});

					auto GibsonMutator = Utils::SpawnActor<AFortAthenaMutator_Gibson>({0, 0, -99999}, {});
					GibsonMutator->CachedBotManager = BotManager;
					GibsonMutator->CachedGameMode = GM;
					GibsonMutator->CachedGameState = GS;
					GM->MutatorListComponent->Mutators.Add(GibsonMutator);
				}

				auto TS = UGameplayStatics::GetTimeSeconds(UWorld::Get());
				auto DR = 60.f;

				GS->WarmupCountdownEndTime = TS + DR;
				GM->WarmupCountdownDuration = DR;
				GS->WarmupCountdownStartTime = TS;
				GM->WarmupEarlyCountdownDuration = DR;

				Vehicles::SpawnVehicles();

				Utils::ExecHook(Utils::FindObject<UFunction>("/Game/Athena/Items/Consumables/HappyGhost/Prj_Athena_HappyGhost.Prj_Athena_HappyGhost_C.ReceiveHit"), Misc::ReceiveHit, Misc::ReceiveHitOG); // for some reason i gotta do this here...
			}

			FString Err;
			FURL URL;
			URL.Port = 7777;

			((InitListenType)InitListen)(NetDriver, UWorld::Get(), URL, false, Err);
			((SetWorldType)SetWorld)(NetDriver, UWorld::Get());
			SetConsoleTitleA("Atlas | Listening");
			GM->bWorldIsReady = true;
		}

		auto Ret = GM->AlivePlayers.Num() > 0;
		if (!Ret)
		{
			auto TS = UGameplayStatics::GetTimeSeconds(UWorld::Get());
			auto DR = 60.f;

			GS->WarmupCountdownEndTime = TS + DR;
			GM->WarmupCountdownDuration = DR;
			GS->WarmupCountdownStartTime = TS;
			GM->WarmupEarlyCountdownDuration = DR;
		}

		return Ret;
	}

	static APawn *SpawnDefaultPawnForHook(AFortGameModeAthena *GM, AFortPlayerControllerAthena *PC, AActor *StartSpot)
	{
		auto Pawn = GM->SpawnDefaultPawnAtTransform(PC, StartSpot->GetTransform());

		PC->WorldInventory->Inventory.ReplicatedEntries.ResetNum();
		PC->WorldInventory->Inventory.ItemInstances.ResetNum();

		for (auto &SI : GM->StartingItems)
			if (SI.Count)
				Inventory::GiveItem(PC, SI.Item, SI.Count);
		Inventory::GiveItem(PC, PC->CosmeticLoadoutPC.Pickaxe->WeaponDefinition);

		// this dont work
		static bool bSetupNavSystem = false;
		if (!bSetupNavSystem)
		{
			bSetupNavSystem = true;
			auto NavSystem = (UNavigationSystemV1 *)UWorld::Get()->NavigationSystem;

			NavSystem->DefaultAgentName = UKismetStringLibrary::Conv_StringToName(L"MANG");
			*(uint8 *)(__int64(NavSystem) + 952) = 0;
			*(uint32 *)(__int64(NavSystem) + 88) = 1;
			NavSystem->bAutoCreateNavigationData = true;
			NavSystem->bGenerateNavigationOnlyAroundNavigationInvokers = true;

			((void (*)(UNavigationSystemV1 *NavSystem))(ImageBase + 0x5065120))(NavSystem);

			if (NavSystem->MainNavData)
				NavSystem->MainNavData->RuntimeGeneration = ERuntimeGenerationType::Dynamic;
		}

		return Pawn;
	}

	static inline void (*HandleStartingNewPlayerOG)(AGameModeBase *, APlayerController *);
	static void HandleStartingNewPlayerHook(AGameModeBase *GM, APlayerController *NewPlayer)
	{
		auto GS = AFortGameStateAthena::Get();
		if (GS->GamePhase >= EAthenaGamePhase::Aircraft)
			return NewPlayer->ClientReturnToMainMenu(L"womp womp");
		AFortPlayerStateAthena *PlayerState = (AFortPlayerStateAthena *)NewPlayer->PlayerState;
		AFortPlayerControllerAthena *PC = (AFortPlayerControllerAthena *)NewPlayer;

		for (auto &Modifier : GS->CurrentPlaylistInfo.BasePlaylist->ModifierList)
		{
			for (auto &AbilitySet : Modifier.Get()->PersistentAbilitySets)
				if (!AbilitySet.DeliveryRequirements.bConsiderTeam && AbilitySet.DeliveryRequirements.bApplyToPlayerPawns && AbilitySet.AbilitySets)
					for (auto &AbilitySet : AbilitySet.AbilitySets)
						Abilities::GiveAbilitySet(PlayerState, AbilitySet.Get());
			for (auto &GameplayEffectSet : Modifier->PersistentGameplayEffects)
				if (!GameplayEffectSet.DeliveryRequirements.bConsiderTeam && GameplayEffectSet.DeliveryRequirements.bApplyToPlayerPawns && GameplayEffectSet.GameplayEffects)
					for (auto &GameplayEffect : GameplayEffectSet.GameplayEffects)
					{
						auto GE = GameplayEffect.GameplayEffect.Get();

						if (!GE)
							continue;
						PlayerState->AbilitySystemComponent->BP_ApplyGameplayEffectToSelf(GE, GameplayEffect.Level, FGameplayEffectContextHandle());
					}
		}

		PlayerState->SeasonLevelUIDisplay = PC->XPComponent->CurrentLevel;
		PlayerState->OnRep_SeasonLevelUIDisplay();
		PC->XPComponent->bRegisteredWithQuestManager = true;
		PC->XPComponent->OnRep_bRegisteredWithQuestManager();

		PC->GetQuestManager(ESubGame::Athena)->InitializeQuestAbilities(PC->Pawn);

		if (!PC->MatchReport)
			PC->MatchReport = (UAthenaPlayerMatchReport *)UGameplayStatics::SpawnObject(UAthenaPlayerMatchReport::StaticClass(), PC);

		PlayerState->SquadId = PlayerState->TeamIndex - 3;
		PlayerState->OnRep_SquadId();

		FGameMemberInfo Member;
		Member.MostRecentArrayReplicationKey = -1;
		Member.ReplicationID = -1;
		Member.ReplicationKey = -1;
		Member.TeamIndex = PlayerState->TeamIndex;
		Member.SquadId = PlayerState->SquadId;
		Member.MemberUniqueId = PlayerState->UniqueId;

		GS->GameMemberInfoArray.Members.Add(Member);
		GS->GameMemberInfoArray.MarkArrayDirty();

		return HandleStartingNewPlayerOG(GM, NewPlayer);
	}

	static inline void (*OnAircraftExitedDropZoneOG)(AFortGameModeAthena *, AFortAthenaAircraft *);
	static void OnAircraftExitedDropZone(AFortGameModeAthena *GM, AFortAthenaAircraft *Aircraft)
	{
		if (LateGame)
		{
			for (auto &Player : GM->AlivePlayers)
			{
				if (Player->IsInAircraft())
				{
					Player->GetAircraftComponent()->ServerAttemptAircraftJump({});
				}
			}
		}
		return OnAircraftExitedDropZoneOG(GM, Aircraft);
	}

public:
	static inline bool startedBus = false;

private:
	static inline void (*TickFlushOG)(UNetDriver *);
	static void TickFlushHook(UNetDriver *Driver)
	{
		if (Driver->ReplicationDriver)
			((void (*)(UReplicationDriver *))ServerReplicateActors)(Driver->ReplicationDriver);

		if (!startedBus)
		{
			static auto GS = AFortGameStateAthena::Get();
			auto Time = UGameplayStatics::GetTimeSeconds(UWorld::Get());
			if (GS->WarmupCountdownEndTime <= Time)
			{
				startedBus = true;

				((void (*)(AGameModeBase *, int))(ImageBase + 0x1ed5710))(AFortGameModeAthena::Get(), 0);
			}
		}
		else
		{
			for (auto &Bot : BotArray)
			{
				Bot->Tick();
			}
		}

		return TickFlushOG(Driver);
	}

public:
	static void HookFunctions()
	{
		Utils::Hook(ReadyToStartMatch, ReadyToStartMatchHook, ReadyToStartMatchOG);
		Utils::Hook(TickFlush, TickFlushHook, TickFlushOG);
		Utils::Hook(ImageBase + 0x1ebade0, OnAircraftExitedDropZone, OnAircraftExitedDropZoneOG);
		Utils::Hook<AFortGameModeAthena>(HandleStartingNewPlayerVft, HandleStartingNewPlayerHook, HandleStartingNewPlayerOG);
		Utils::Hook<AFortGameModeAthena>(SpawnDefaultPawnForVft, SpawnDefaultPawnForHook);
	}
};