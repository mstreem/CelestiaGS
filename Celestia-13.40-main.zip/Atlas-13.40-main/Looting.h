#pragma once
#include "pch.h"
#include "Utils.h"
#include "Inventory.h"
#include "LateGame.h"

class Looting
{
	static inline UDataTable *LootTierData = nullptr;
	static inline UDataTable *LootPackages = nullptr;

	static int GetLevel(const FDataTableCategoryHandle &categoryh)
	{
		auto GS = AFortGameStateAthena::Get();
		auto DataTable = categoryh.DataTable;

		if (!DataTable)
			return 0;

		if (!categoryh.ColumnName.ComparisonIndex)
			return 0;

		if (!categoryh.RowContents.ComparisonIndex)
			return 0;

		TArray<FFortLootLevelData *> lldata;

		for (auto &LootLevelDataPair : (TMap<FName, FFortLootLevelData *>)categoryh.DataTable->RowMap)
		{
			if (LootLevelDataPair.Value()->Category != categoryh.RowContents)
				continue;

			lldata.Add(LootLevelDataPair.Value());
		}

		if (lldata.Num() > 0)
		{
			int ind = -1;
			int ll = 0;

			for (int i = 0; i < lldata.Num(); i++)
			{
				if (lldata[i]->LootLevel <= GS->WorldLevel && lldata[i]->LootLevel > ll)
				{
					ll = lldata[i]->LootLevel;
					ind = i;
				}
			}

			if (ind != -1)
			{
				auto subbed = lldata[ind]->MaxItemLevel - lldata[ind]->MinItemLevel;

				if (subbed <= -1)
					subbed = 0;
				else
				{
					auto calc = (int)(((float)rand() / 32767) * (float)(subbed + 1));
					if (calc <= subbed)
						subbed = calc;
				}

				return subbed + lldata[ind]->MinItemLevel;
			}
		}

		return 0;
	}

public:
	template <typename T>
	static pair<FName, T *> PickWeighted(map<FName, T *> &Map, float (*RandFunc)(float))
	{
		float TotalWeight = accumulate(Map.begin(), Map.end(), 0.0f, [&](float acc, const pair<FName, T *> &p)
									   { return acc + p.second->Weight; });
		float RandomNumber = RandFunc(TotalWeight);

		for (auto &Element : Map)
		{
			float Weight = Element.second->Weight;

			if (Weight == 0)
				continue;

			if (RandomNumber <= Weight)
				return Element;

			RandomNumber -= Weight;
		}

		pair<FName, T *> None;
		return None;
	}

	static inline map<FName, FFortLootPackageData *> LPGroupsAll;

private:
	static void SetupLDSForPackage(TArray<FFortItemEntry *> &LDS, SDK::FName Package, int i, int WorldLevel = AFortGameStateAthena::Get()->WorldLevel)
	{
		auto GS = AFortGameStateAthena::Get();

		if (!LootPackages)
		{
			LootPackages = GS->CurrentPlaylistInfo.BasePlaylist->LootPackages.Get();
			if (!LootPackages)
				LootPackages = Utils::FindObject<UDataTable>("/Game/Items/Datatables/AthenaLootPackages_Client.AthenaLootPackages_Client");
			if (!LootPackages)
				return;
			for (auto &[Key, Val] : (TMap<FName, FFortLootPackageData *>)LootPackages->RowMap)
			{
				LPGroupsAll[Key] = Val;
			}
			if (auto CompositeTable = LootPackages->Cast<UCompositeDataTable>())
			{
				for (auto &PT : CompositeTable->ParentTables)
				{
					for (auto &[Key, Val] : (TMap<FName, FFortLootPackageData *>)PT->RowMap)
					{
						if (LPGroupsAll.contains(Key) && LPGroupsAll[Key]->Weight <= Val->Weight)
							continue;
						else
							LPGroupsAll[Key] = Val;
					}
				}
			}
		}

		map<FName, FFortLootPackageData *> LPGroups;
		for (auto const &[Key, Val] : LPGroupsAll)
		{
			if (Val->LootPackageID == Package && (i != -1 ? Val->LootPackageCategory == i : true) && (WorldLevel >= 0 ? ((Val->MaxWorldLevel >= 0 ? WorldLevel <= Val->MaxWorldLevel : true) && (Val->MinWorldLevel >= 0 ? WorldLevel >= Val->MinWorldLevel : true)) : true))
				LPGroups[Key] = Val;
		}
		if (LPGroups.size() == 0)
			return;

		auto pair = PickWeighted(LPGroups, [](float Total)
								 { return ((float)rand() / 32767) * Total; });
		auto LP = pair.second;
		if (!LP)
			return;
		if (LP->LootPackageCall.Num() > 1)
		{
			for (int i = 0; i < LP->Count; i++)
			{
				SetupLDSForPackage(LDS, UKismetStringLibrary::Conv_StringToName(LP->LootPackageCall), 0);
			}

			return;
		}

		UFortWorldItemDefinition *ID = (UFortWorldItemDefinition *)LP->ItemDefinition.Get();
		if (!ID)
			return;

		bool found = false;
		for (auto &LD : LDS)
		{
			if (LD->ItemDefinition == ID)
			{
				LD->Count += LP->Count;
				float MaxStackF;
				if (ID->MaxStackSize.Curve.CurveTable)
					UDataTableFunctionLibrary::EvaluateCurveTableRow(ID->MaxStackSize.Curve.CurveTable, ID->MaxStackSize.Curve.RowName, 0.f, nullptr, &MaxStackF, FString());
				else
					MaxStackF = ID->MaxStackSize.Value;
				auto MaxStack = (int32)MaxStackF;
				if (LD->Count > MaxStack && Inventory::GetQuickbar(LD->ItemDefinition) == EFortQuickBars::Secondary)
				{
					auto OGCount = LD->Count;
					LD->Count = MaxStack;

					auto IE = Inventory::MakeItemEntry(ID, OGCount - MaxStack, std::clamp(GetLevel(ID->LootLevelData), ID->MinLevel, ID->MaxLevel));

					LDS.Add(IE);
				}
				if (Inventory::GetQuickbar(LD->ItemDefinition) == EFortQuickBars::Secondary)
					found = true;
			}
		}

		if (!found && LP->Count > 0)
		{
			auto IE = Inventory::MakeItemEntry(ID, LP->Count, clamp(GetLevel(ID->LootLevelData), ID->MinLevel, ID->MaxLevel));
			if (ID->IsA<UFortWeaponRangedItemDefinition>() && !ID->IsStackable() && ID->GetAmmoWorldItemDefinition_BP())
			{
				FFortLootPackageData *Group = nullptr;
				auto AD = ID->GetAmmoWorldItemDefinition_BP();
				static auto AmmoSmall = UKismetStringLibrary::Conv_StringToName(L"WorldList.AthenaAmmoSmall");
				for (auto const &[Key, Val] : LPGroupsAll)
				{
					if (Val->LootPackageID == AmmoSmall && Val->ItemDefinition == AD)
					{
						Group = Val;
						break;
					}
				}
				if (Group)
				{
					auto IE2 = Inventory::MakeItemEntry(ID->GetAmmoWorldItemDefinition_BP(), Group->Count, 0);
					LDS.Add(IE2);
				}
			}

			LDS.Add(IE);
		}
	}

	static TArray<FFortItemEntry *> ChooseLootForContainer(FName TG, int LootTier = -1, int WorldLevel = AFortGameStateAthena::Get()->WorldLevel)
	{
		static map<FName, FFortLootTierData *> LTDGroupsAll;
		auto GS = AFortGameStateAthena::Get();
		if (!LootTierData)
		{
			LootTierData = GS->CurrentPlaylistInfo.BasePlaylist->LootTierData.Get();
			if (!LootTierData)
				LootTierData = Utils::FindObject<UDataTable>("/Game/Items/Datatables/AthenaLootTierData_Client.AthenaLootTierData_Client");
			if (!LootTierData)
				return {};
			for (auto &[Key, Val] : (TMap<FName, FFortLootTierData *>)LootTierData->RowMap)
			{
				LTDGroupsAll[Key] = Val;
			}
			if (auto CompositeTable = LootTierData->Cast<UCompositeDataTable>())
			{
				for (auto &PT : CompositeTable->ParentTables)
				{
					for (auto &[Key, Val] : (TMap<FName, FFortLootTierData *>)PT->RowMap)
					{
						if (LTDGroupsAll.contains(Key) && LTDGroupsAll[Key]->Weight <= Val->Weight)
							continue;
						else
							LTDGroupsAll[Key] = Val;
					}
				}
			}
		}

		map<FName, FFortLootTierData *> LTDGroups;
		for (auto const &[Key, Val] : LTDGroupsAll)
		{
			if (Val->TierGroup == TG && (LootTier == -1 ? true : LootTier == Val->LootTier))
				LTDGroups[Key] = Val;
		}
		auto pair = PickWeighted(LTDGroups, [](float Total)
								 { return ((float)rand() / 32767) * Total; });
		auto LTD = pair.second;
		if (!LTD)
			return {};

		float LDCount = 0;
		if (LTD->NumLootPackageDrops > 0)
		{
			LDCount = LTD->NumLootPackageDrops < 1 ? 1 : (float)((int)((LTD->NumLootPackageDrops * 2) - .5f) >> 1);
			if (LTD->NumLootPackageDrops > 1)
			{
				float idk = LTD->NumLootPackageDrops - LDCount;
				if (idk > 0.0000099999997f)
					LDCount += idk >= ((float)rand() / 32767);
			}
		}

		float AmLD = 0;
		float MinLD = 0;

		for (auto &M : LTD->LootPackageCategoryMinArray)
			MinLD += M;

		int sum = 0;

		for (int i = 0; i < LTD->LootPackageCategoryWeightArray.Num(); ++i)
		{
			if (LTD->LootPackageCategoryWeightArray[i] > 0 && LTD->LootPackageCategoryMaxArray[i] != 0)
				sum += LTD->LootPackageCategoryWeightArray[i];
		}

		while (sum > 0)
		{
			MinLD++;

			if (MinLD >= LTD->NumLootPackageDrops)
			{
				AmLD = MinLD;
				break;
			}

			sum--;
		}

		if (!AmLD)
			AmLD = MinLD;
		TArray<FFortItemEntry *> LDS;

		for (int i = 0; i < AmLD && i < LTD->LootPackageCategoryMinArray.Num(); i++)
		{
			for (int j = 0; j < LTD->LootPackageCategoryMinArray[i] && LTD->LootPackageCategoryMinArray[i] >= 1; j++)
			{
				SetupLDSForPackage(LDS, LTD->LootPackage, i, WorldLevel);
			}
		}

		return LDS;
	}

	static void SpawnLoot(FName &TG, FVector Loc, EFortPickupSourceTypeFlag ST = EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource SS = EFortPickupSpawnSource::Unset)
	{
		auto &RTG = TG;
		for (auto &[TierGroup, Redirect] : AFortGameModeAthena::Get()->RedirectAthenaLootTierGroups)
		{
			if (TierGroup == TG)
			{
				RTG = Redirect;
				break;
			}
		}
		auto LDS = ChooseLootForContainer(RTG);
		for (auto &LD : LDS)
			Inventory::SpawnPickup(Loc, *LD, ST, SS);
	}
	static void SpawnLoot(ABuildingContainer *Container)
	{
		auto &RTG = Container->SearchLootTierGroup;
		for (auto &[TierGroup, Redirect] : AFortGameModeAthena::Get()->RedirectAthenaLootTierGroups)
		{
			if (TierGroup == Container->SearchLootTierGroup)
			{
				RTG = Redirect;
				break;
			}
		}
		auto LDS = ChooseLootForContainer(RTG);
		EFortPickupSpawnSource SS = EFortPickupSpawnSource::Unset;
		if (Container->IsA<ATiered_Ammo_Athena_C>())
			SS = EFortPickupSpawnSource::AmmoBox;
		else if (Container->IsA<ATiered_Chest_Athena_C>())
			SS = EFortPickupSpawnSource::Chest;
		for (auto &LD : LDS)
			Inventory::SpawnPickup(Container, *LD, Container->IsA<ATiered_Ammo_Athena_C>() || Container->IsA<ATiered_Chest_Athena_C>() ? EFortPickupSourceTypeFlag::Container : EFortPickupSourceTypeFlag::FloorLoot, SS);
	}

public:
	static void SpawnFloorLootForContainer(UBlueprintGeneratedClass *ContainerType)
	{
		auto Containers = Utils::GetAll<ABuildingContainer>(ContainerType);

		for (auto &BCContainer : Containers)
		{
			// SpawnLoot(BCContainer->SearchLootTierGroup, BCContainer->K2_GetActorLocation() + BCContainer->GetActorForwardVector() * BCContainer->LootSpawnLocation_Athena.X + BCContainer->GetActorRightVector() * BCContainer->LootSpawnLocation_Athena.Y + BCContainer->GetActorUpVector() * BCContainer->LootSpawnLocation_Athena.Z);
			BCContainer->K2_DestroyActor();
		}

		Containers.Free();
		Utils::Log("Spawned floor loot for container " + ContainerType->GetName());
	}

private:
	static bool PickLootDrops(UObject *WorldContextObject, TArray<FFortItemEntry> *OutLootToDrop, FName TierGroupName, int32 WorldLevel, int32 ForcedLootTier)
	{
		if (__int64(_ReturnAddress()) == ImageBase + 0x2f90305)
		{
			auto LDS = ChooseLootForContainer(TierGroupName, ForcedLootTier, WorldLevel);
			for (int32 i = 0; i < LDS.Num(); i++)
			{
				OutLootToDrop->Add(*LDS[i]);
			}

			return true;
		}
		return false;
	}

	static inline AFortPickup *(*PickupRet0)();
	static AFortPickup *SupplySpawnPickup(AFortAthenaSupplyDrop *Drop, UFortWeaponItemDefinition *ItemDefinition, int32 NumberToSpawn, AFortPawn *TriggeringPawn, FVector &Position, FVector &Direction)
	{
		if (__int64(_ReturnAddress()) == ImageBase + 0x2e305eB)
		{
			return Inventory::SpawnPickup(Position, ItemDefinition, NumberToSpawn, Inventory::GetStats(ItemDefinition->Cast<UFortWeaponItemDefinition>())->ClipSize, EFortPickupSourceTypeFlag::Container, EFortPickupSpawnSource::SupplyDrop);
		}
		return PickupRet0();
	}

public:
	static inline bool bScuffed = false;

private:
	static bool SpawnLootHook(ABuildingContainer *BuildingContainer)
	{
		if (AFortGameStateAthena::Get()->GamePhase > EAthenaGamePhase::Aircraft && LateGame)
			return true;
		if (!bScuffed)
		{
			SpawnLoot(BuildingContainer);

			BuildingContainer->bAlreadySearched = true;
			BuildingContainer->OnRep_bAlreadySearched();
			BuildingContainer->SearchBounceData.SearchAnimationCount++;
			BuildingContainer->BounceContainer();
		}

		return true;
	}

public:
	static void HookFunctions()
	{
		Utils::Hook(ImageBase + 0x91da70, PickLootDrops);
		Utils::Hook(ImageBase + 0x1e83630, SupplySpawnPickup, PickupRet0);
		Utils::Hook(ImageBase + 0x213e180, SpawnLootHook);
	}
};