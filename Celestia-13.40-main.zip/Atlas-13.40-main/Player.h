#pragma once
#include "pch.h"
#include "Abilities.h"
#include "XP.h"
#include "GameMode.h"

class Player
{
	static void GiveModifier(AFortPlayerControllerAthena *PC, UFortGameplayModifierItemDefinition *Modifier)
	{
		if (!PC || !PC->MyFortPawn || !Modifier)
			return;
		for (auto &Ability : Modifier->PersistentAbilitySets)
			if (Ability.DeliveryRequirements.bApplyToPlayerPawns)
				for (auto &abi : Ability.AbilitySets)
					Abilities::GiveAbilitySet(PC->MyFortPawn, abi);
		for (auto &Effect : Modifier->PersistentGameplayEffects)
			if (Effect.DeliveryRequirements.bApplyToPlayerPawns)
				for (auto &eff : Effect.GameplayEffects)
					PC->MyFortPawn->AbilitySystemComponent->BP_ApplyGameplayEffectToSelf(eff.GameplayEffect.Get(), eff.Level, PC->MyFortPawn->AbilitySystemComponent->MakeEffectContext());
	}

	static inline void (*ServerAcknowledgePossessionOG)(AFortPlayerControllerAthena *PC, APawn *Pawn);
	static void ServerAcknowledgePossessionHook(AFortPlayerControllerAthena *PC, APawn *Pawn)
	{
		PC->AcknowledgedPawn = Pawn;

		static UFortAbilitySet *AbilitySet = Utils::FindObject<UFortAbilitySet>("/Game/Abilities/Player/Generic/Traits/DefaultPlayer/GAS_AthenaPlayer.GAS_AthenaPlayer");
		Abilities::GiveAbilitySet((AFortPlayerPawn *)Pawn, AbilitySet);

		auto &ModifierList = AFortGameStateAthena::Get()->CurrentPlaylistInfo.BasePlaylist->ModifierList;
		for (auto &mod : ModifierList)
			GiveModifier(PC, Utils::FindObject<UFortGameplayModifierItemDefinition>(mod.ObjectID.AssetPathName.ToString()));

		PC->bBuildFree = true;

		((AFortPlayerStateAthena *)PC->PlayerState)->HeroType = PC->CosmeticLoadoutPC.Character->HeroDefinition;
		((void (*)(APlayerState *, APawn *))ApplyCharacterCustomization)(PC->PlayerState, Pawn);

		return ServerAcknowledgePossessionOG(PC, Pawn);
	}

	static void ServerSendZiplineState(AFortPlayerPawnAthena *Pawn, FZiplinePawnState State)
	{
		Pawn->ZiplineState = State;
		((void (*)(AFortPlayerPawn *))(ImageBase + 0x2902140))(Pawn);

		if (State.bJumped)
		{
			Pawn->LaunchCharacter(FVector{0, 0, 1200}, false, false);
		}
	}

	static void ServerClientIsReadyToRespawn(AFortPlayerControllerAthena *PC)
	{
		auto PS = PC->PlayerState->Cast<AFortPlayerStateAthena>();
		if (PS->RespawnData.bRespawnDataAvailable && PS->RespawnData.bServerIsReady)
		{
			PS->RespawnData.bClientIsReady = true;

			FTransform Transform(PS->RespawnData.RespawnLocation, PS->RespawnData.RespawnRotation);
			auto Pawn = (AFortPlayerPawnAthena *)AFortGameModeAthena::Get()->SpawnDefaultPawnAtTransform(PC, Transform);
			PC->Possess(Pawn);
			Pawn->SetHealth(100);
			Pawn->SetShield(0);

			PC->RespawnPlayerAfterDeath(true);
			Pawn->BeginSkydiving(true);
		}
	}

	static inline void (*ServerHandlePickupInfoOG)(AFortPlayerPawnAthena *Pawn, AFortPickup *Pickup, FFortPickupRequestInfo &Params);
	static void ServerHandlePickupInfo(AFortPlayerPawnAthena *Pawn, AFortPickup *Pickup, FFortPickupRequestInfo &Params)
	{
		if (!Pawn || !Pickup || Pickup->bPickedUp)
			return ServerHandlePickupInfoOG(Pawn, Pickup, Params);
		if (Pawn->GetDistanceTo(Pickup) > 500.f)
			return;

		if ((Params.bTrySwapWithWeapon || Params.bUseRequestedSwap) && Inventory::GetQuickbar(Pawn->CurrentWeapon->WeaponData) == EFortQuickBars::Primary && Inventory::GetQuickbar(Pickup->PrimaryPickupItemEntry.ItemDefinition) == EFortQuickBars::Primary)
		{
			auto PC = (AFortPlayerControllerAthena *)Pawn->Controller;
			auto SwapEntry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([Params](FFortItemEntry &entry)
																					{ return entry.ItemGuid == Params.SwapWithItem; });
			PC->SwappingItemDefinition = (UFortWorldItemDefinition *)SwapEntry; // proper af
		}
		Pawn->IncomingPickups.Add(Pickup);

		Pickup->PickupLocationData.bPlayPickupSound = Params.bPlayPickupSound;
		Pickup->PickupLocationData.FlyTime = 0.4f;
		Pickup->PickupLocationData.ItemOwner = Pawn;
		Pickup->PickupLocationData.PickupGuid = Pickup->PrimaryPickupItemEntry.ItemGuid;
		Pickup->PickupLocationData.PickupTarget = Pawn;
		Pickup->PickupLocationData.StartDirection = Params.Direction.QuantizeNormal();
		Pickup->OnRep_PickupLocationData();

		Pickup->bPickedUp = true;
		Pickup->OnRep_bPickedUp();
		return ServerHandlePickupInfoOG(Pawn, Pickup, Params);
	}

	static inline void *(*DispatchRequestOG)(__int64, __int64, __int64);
	static void *DispatchRequestHook(__int64 a1, __int64 a2, __int64 a3)
	{
		return DispatchRequestOG(a1, a2, 3);
	}

	static void ServerAttemptAircraftJumpHook(UFortControllerComponent_Aircraft *Comp, FRotator ClientRot)
	{
		auto PC = (AFortPlayerControllerAthena *)Comp->GetOwner();
		static auto GM = AFortGameModeAthena::Get();
		static auto GS = AFortGameStateAthena::Get();
		if (LateGame)
		{
			auto Pawn = GM->SpawnDefaultPawnAtTransform(PC, GS->Aircrafts[0]->GetTransform());
			PC->Possess(Pawn);

			PC->WorldInventory->Inventory.ReplicatedEntries.ResetNum();
			PC->WorldInventory->Inventory.ItemInstances.ResetNum();

			for (auto &SI : GM->StartingItems)
				if (SI.Count > 0)
					Inventory::GiveItem(PC, SI.Item, SI.Count);
			Inventory::GiveItem(PC, PC->CosmeticLoadoutPC.Pickaxe->WeaponDefinition);
		}
		else
			GM->RestartPlayer(PC);

		PC->MyFortPawn->BeginSkydiving(true);
		if (LateGame)
		{
			PC->MyFortPawn->SetHealth(100);
			PC->MyFortPawn->SetShield(100);

			LateGameInternal::Guns Guns;
			auto &Shotgun = Guns.Shotguns[rand() % (Guns.Shotguns.size() - 1)];
			auto &AssaultRifle = Guns.AssaultRifles[rand() % (Guns.AssaultRifles.size() - 1)];
			auto &SubmachineGun = Guns.SubmachineGuns[rand() % (Guns.SubmachineGuns.size() - 1)];
			auto &Utility = Guns.Utilities[rand() % (Guns.Utilities.size() - 1)];
			auto &Heal = Guns.Heals[rand() % (Guns.Heals.size() - 1)];
			auto ShotgunClipSize = Inventory::GetStats((UFortWeaponItemDefinition *)Shotgun.Item)->ClipSize;
			auto AssaultRifleClipSize = Inventory::GetStats((UFortWeaponItemDefinition *)AssaultRifle.Item)->ClipSize;
			auto SubmachineGunClipSize = Inventory::GetStats((UFortWeaponItemDefinition *)SubmachineGun.Item)->ClipSize;
			auto UtilityClipSize = Inventory::GetStats((UFortWeaponItemDefinition *)Utility.Item)->ClipSize;

			Inventory::GiveItem(PC, Guns.Wood, 500);
			Inventory::GiveItem(PC, Guns.Stone, 500);
			Inventory::GiveItem(PC, Guns.Metal, 500);
			Inventory::GiveItem(PC, Guns.AssaultAmmo, 250);
			Inventory::GiveItem(PC, Guns.ShotgunAmmo, 50);
			Inventory::GiveItem(PC, Guns.SubmachineAmmo, 400);
			Inventory::GiveItem(PC, Guns.RocketAmmo, 6);

			auto SIE = Inventory::GiveItem(PC, Shotgun.Item, Shotgun.Count, ShotgunClipSize, 0, true, false);
			auto ARIE = Inventory::GiveItem(PC, AssaultRifle.Item, AssaultRifle.Count, AssaultRifleClipSize, true, false);
			auto SGIE = Inventory::GiveItem(PC, SubmachineGun.Item, SubmachineGun.Count, SubmachineGunClipSize, true, false);
			auto UIE = Inventory::GiveItem(PC, Utility.Item, Utility.Count, UtilityClipSize, true, false);
			auto HIE = Inventory::GiveItem(PC, Heal.Item, Heal.Count, true, false);
			PC->WorldInventory->Inventory.MarkItemDirty2(SIE->ItemEntry);
			PC->WorldInventory->Inventory.MarkItemDirty2(ARIE->ItemEntry);
			PC->WorldInventory->Inventory.MarkItemDirty2(SGIE->ItemEntry);
			PC->WorldInventory->Inventory.MarkItemDirty2(UIE->ItemEntry);
			PC->WorldInventory->Inventory.MarkItemDirty2(HIE->ItemEntry);
			PC->WorldInventory->Inventory.MarkArrayDirty();
		}
	}

	static void ServerExecuteInventoryItemHook(AFortPlayerControllerAthena *PC, FGuid Guid)
	{
		if (!PC)
			return;
		auto entry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([Guid](FFortItemEntry &entry)
																			{ return entry.ItemGuid == Guid; });

		if (!entry || !PC->MyFortPawn)
			return;
		UFortWeaponItemDefinition *ItemDef = (UFortWeaponItemDefinition *)entry->ItemDefinition;
		if (auto Gadget = ItemDef->Cast<UFortGadgetItemDefinition>())
			ItemDef = Gadget->GetWeaponItemDefinition();
		else if (auto Deco = ItemDef->Cast<UFortDecoItemDefinition>())
		{
			PC->MyFortPawn->PickUpActor(nullptr, Deco);
			PC->MyFortPawn->CurrentWeapon->ItemEntryGuid = Guid;

			if (auto CT = PC->MyFortPawn->CurrentWeapon->Cast<AFortDecoTool_ContextTrap>())
				CT->ContextTrapItemDefinition = (UFortContextTrapItemDefinition *)Deco;
			return;
		}
		PC->MyFortPawn->EquipWeaponDefinition(ItemDef, Guid);
	}

	static bool PickupLogic(AFortPlayerControllerAthena *PC, FFortItemEntry *itemEntry, FFortItemEntry &PickupEntry, int Items, int MaxStack)
	{
		if (itemEntry && itemEntry->ItemDefinition->IsStackable())
		{
			if (itemEntry->ItemDefinition->IsA<UFortAmmoItemDefinition>() || itemEntry->ItemDefinition->IsA<UFortResourceItemDefinition>())
			{
				auto State = itemEntry->StateValues.Search([](FFortItemEntryStateValue &Value)
														   { return Value.StateType == EFortItemEntryState::ShouldShowItemToast; });
				State->IntValue = true;
			}
			itemEntry->Count += PickupEntry.Count;
			if (itemEntry->Count > MaxStack)
			{
				int OGCount = itemEntry->Count;
				itemEntry->Count = MaxStack;
				if (PickupEntry.ItemDefinition->bAllowMultipleStacks)
				{
					if (Items == 5)
						Inventory::SpawnPickup(PC->GetViewTarget()->K2_GetActorLocation(), *itemEntry, EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::Unset, PC->MyFortPawn, OGCount - MaxStack);
					else
						Inventory::GiveItem(PC, PickupEntry, OGCount - MaxStack, false);
				}
				else
					Inventory::SpawnPickup(PC->GetViewTarget()->K2_GetActorLocation(), *itemEntry, EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::Unset, PC->MyFortPawn, OGCount - MaxStack);
			}
			Inventory::ReplaceEntry(PC, *itemEntry);
			return true;
		}
		return false;
	}

	static auto InternalPickup(AFortPlayerControllerAthena *PC, FFortItemEntry &PickupEntry)
	{
		float MaxStackF;
		if (PickupEntry.ItemDefinition->MaxStackSize.Curve.CurveTable)
			UDataTableFunctionLibrary::EvaluateCurveTableRow(PickupEntry.ItemDefinition->MaxStackSize.Curve.CurveTable, PickupEntry.ItemDefinition->MaxStackSize.Curve.RowName, 0.f, nullptr, &MaxStackF, FString());
		else
			MaxStackF = PickupEntry.ItemDefinition->MaxStackSize.Value;
		auto MaxStack = (int32)MaxStackF;
		int Items = 0;
		for (auto &Item : PC->WorldInventory->Inventory.ReplicatedEntries)
		{
			if (Inventory::GetQuickbar(Item.ItemDefinition) == EFortQuickBars::Primary)
				Items++;
		}
		auto &pEntry = PickupEntry;
		auto itemEntry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([pEntry, MaxStack](FFortItemEntry &entry)
																				{ return entry.ItemDefinition == pEntry.ItemDefinition && entry.Count < MaxStack; });
		if (Items >= 5 && Inventory::GetQuickbar(PC->MyFortPawn->CurrentWeapon->WeaponData) == EFortQuickBars::Primary && Inventory::GetQuickbar(PickupEntry.ItemDefinition) == EFortQuickBars::Primary)
		{
			auto &Guid = PC->MyFortPawn->CurrentWeapon->ItemEntryGuid;
			auto itemEntry2 = PC->WorldInventory->Inventory.ReplicatedEntries.Search([Guid](FFortItemEntry &entry)
																					 { return entry.ItemGuid == Guid; });
			if (itemEntry)
			{
				if (PickupLogic(PC, itemEntry, PickupEntry, Items, MaxStack))
					return;
				else if (itemEntry->ItemDefinition == itemEntry2->ItemDefinition)
					goto drop;
			}
			else if (((PC->MyFortPawn->CurrentWeapon->WeaponData == PickupEntry.ItemDefinition && itemEntry2 && (itemEntry2->Count + PickupEntry.Count) > MaxStack) || (itemEntry ? (itemEntry->Count + PickupEntry.Count) > MaxStack : PC->MyFortPawn->CurrentWeapon->WeaponData != PickupEntry.ItemDefinition)))
			{
			drop:
				Inventory::SpawnPickup(PC->GetViewTarget()->K2_GetActorLocation(), *itemEntry2, EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::Unset, PC->MyFortPawn);
				Inventory::Remove(PC, PC->MyFortPawn->CurrentWeapon->GetInventoryGUID());
			}
		}
		auto PL = PickupLogic(PC, itemEntry, PickupEntry, Items, MaxStack);
		if (!PL && (Items >= 5 ? (Items == 5 ? (itemEntry && itemEntry->ItemDefinition->IsStackable()) || (Inventory::GetQuickbar(PC->MyFortPawn->CurrentWeapon->WeaponData) == EFortQuickBars::Primary && Inventory::GetQuickbar(PickupEntry.ItemDefinition) == EFortQuickBars::Primary) || Inventory::GetQuickbar(PickupEntry.ItemDefinition) == EFortQuickBars::Secondary : false) : (!itemEntry || PickupEntry.ItemDefinition->bAllowMultipleStacks)))
		{
			auto WI = Inventory::GiveItem(PC, PickupEntry);
			if (Items == 5 && Inventory::GetQuickbar(WI->ItemEntry.ItemDefinition) == EFortQuickBars::Primary)
			{
				ServerExecuteInventoryItemHook(PC, WI->ItemEntry.ItemGuid);
				PC->ClientEquipItem(WI->ItemEntry.ItemGuid, true);
			}
		}
		else if (!PL && Items >= 5)
		{
			Inventory::SpawnPickup(PC->GetViewTarget()->K2_GetActorLocation(), PickupEntry, EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::Unset, PC->MyFortPawn);
		}
	}

	static inline char (*CompletePickupAnimationOG)(AFortPickup *Pickup);
	static char CompletePickupAnimation(AFortPickup *Pickup)
	{
		auto Pawn = (AFortPlayerPawnAthena *)Pickup->PickupLocationData.PickupTarget;
		if (!Pawn)
			return CompletePickupAnimationOG(Pickup);
		auto PC = (AFortPlayerControllerAthena *)Pawn->Controller;
		if (!PC)
			return CompletePickupAnimationOG(Pickup);
		if (PC->SwappingItemDefinition)
		{
			auto entry = (FFortItemEntry *)PC->SwappingItemDefinition;
			if (entry)
			{
				Inventory::SpawnPickup(PC->GetViewTarget()->K2_GetActorLocation(), *entry, EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::Unset, PC->MyFortPawn);
				// SwapEntry(PC, *entry, Pickup->PrimaryPickupItemEntry);
				Inventory::Remove(PC, entry->ItemGuid);
				Inventory::GiveItem(PC, Pickup->PrimaryPickupItemEntry);
			}
			PC->SwappingItemDefinition = nullptr;
		}
		else
		{
			InternalPickup(PC, Pickup->PrimaryPickupItemEntry);
		}
		return CompletePickupAnimationOG(Pickup);
	}

	static inline void (*OnCapsuleBeginOverlapOG)(AFortPlayerPawnAthena *Pawn, UPrimitiveComponent *OverlappedComp, AActor *OtherActor, UPrimitiveComponent *OtherComp, int32 OtherBodyIndex, bool bFromSweep, FHitResult SweepResult);
	static void OnCapsuleBeginOverlap(AFortPlayerPawnAthena *Pawn, UPrimitiveComponent *OverlappedComp, AActor *OtherActor, UPrimitiveComponent *OtherComp, int32 OtherBodyIndex, bool bFromSweep, FHitResult SweepResult)
	{
		if (!Pawn || Pawn->Controller->IsA<AFortAthenaAIBotController>())
			return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
		auto Pickup = OtherActor->Cast<AFortPickup>();
		if (!Pickup || !Pickup->PrimaryPickupItemEntry.ItemDefinition)
			return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
		float MaxStackF;
		if (Pickup->PrimaryPickupItemEntry.ItemDefinition->MaxStackSize.Curve.CurveTable)
			UDataTableFunctionLibrary::EvaluateCurveTableRow(Pickup->PrimaryPickupItemEntry.ItemDefinition->MaxStackSize.Curve.CurveTable, Pickup->PrimaryPickupItemEntry.ItemDefinition->MaxStackSize.Curve.RowName, 0.f, nullptr, &MaxStackF, FString());
		else
			MaxStackF = Pickup->PrimaryPickupItemEntry.ItemDefinition->MaxStackSize.Value;
		auto MaxStack = (int32)MaxStackF;
		auto itemEntry = ((AFortPlayerControllerAthena *)Pawn->Controller)->WorldInventory->Inventory.ReplicatedEntries.Search([Pickup, MaxStack](FFortItemEntry &entry)
																															   { return entry.ItemDefinition == Pickup->PrimaryPickupItemEntry.ItemDefinition && entry.Count < MaxStack; });
		if (Pickup && Pickup->PawnWhoDroppedPickup != Pawn)
		{
			if ((!itemEntry && Inventory::GetQuickbar(Pickup->PrimaryPickupItemEntry.ItemDefinition) == EFortQuickBars::Secondary) || (itemEntry && itemEntry->Count < MaxStack))
				Pawn->ServerHandlePickup(Pickup, 0.4f, FVector(), true);
		}
		return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
	}

	static inline array<uint8_t, 29> CostMap = {
		0,
		10,
		100,
		150,
		200,
		10,
		100,
		150,
		200,
		10,
		100,
		150,
		200,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		0};

	static inline void (*ServerAttemptInteractOG)(UFortControllerComponent_Interaction *Comp, AActor *ReceivingActor, UPrimitiveComponent *InteractComponent, ETInteractionType InteractType, UObject *OptionalObjectData, EInteractionBeingAttempted InteractionBeingAttempted, int32 RequestID);
	static void ServerAttemptInteract(UFortControllerComponent_Interaction *Comp, AActor *ReceivingActor, UPrimitiveComponent *InteractComponent, ETInteractionType InteractType, UObject *OptionalObjectData, EInteractionBeingAttempted InteractionBeingAttempted, int32 RequestID)
	{
		auto PC = Comp->GetOwner()->Cast<AFortPlayerControllerAthena>();
		ServerAttemptInteractOG(Comp, ReceivingActor, InteractComponent, InteractType, OptionalObjectData, InteractionBeingAttempted, RequestID);
		if (!PC)
			return;

		if (auto Vehicle = ReceivingActor->Cast<AFortAthenaVehicle>())
		{
			auto sInd = Vehicle->FindSeatIndex(PC->MyFortPawn);
			auto comp = Vehicle->GetSeatWeaponComponent(sInd);
			if (!comp)
				return;
			UFortWeaponItemDefinition *Weapon = nullptr;
			for (auto &comp : comp->WeaponSeatDefinitions)
			{
				if (comp.SeatIndex != sInd)
					continue;
				Weapon = comp.VehicleWeapon;
				break;
			}
			if (!Weapon)
				return;
			Inventory::GiveItem(PC, Weapon, 1, Inventory::GetStats(Weapon)->ClipSize);
			auto itemEntry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([Weapon](FFortItemEntry &entry)
																					{ return entry.ItemDefinition == Weapon; });
			PC->ServerExecuteInventoryItem(itemEntry->ItemGuid);
			PC->ClientEquipItem(itemEntry->ItemGuid, true);
		}
		else if (auto DisguiseBooth = ReceivingActor->Cast<AB_HidingProp_PhantomBooth_C>())
		{
			auto Faction = DisguiseBooth->Faction.TagName.ToString();
			auto AGID = Faction == "Athena.Faction.Ego" ? DisguiseBooth->AGID_Ego : (Faction == "Athena.Faction.Default.POI.Box" ? Utils::FindObject<UFortGadgetItemDefinition>("/Game/Athena/Items/EnvironmentalItems/HidingProps/Props/PhantomBooth/AGID_Disguise_Scrapyard.AGID_Disguise_Scrapyard") : DisguiseBooth->AGID_Alter);

			auto InventoryEntry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([AGID](FFortItemEntry &Entry)
																						 { return Entry.ItemDefinition == AGID; });
			auto HidingPlayersIndex = DisguiseBooth->HidingPlayers.SearchIndex([PC](AFortPawn *Pawn)
																			   { return Pawn == PC->MyFortPawn; });

			if (InventoryEntry)
			{
				Inventory::Remove(PC, InventoryEntry->ItemGuid);
				DisguiseBooth->HidingPlayers.Remove(HidingPlayersIndex);
			}
			else
			{
				DisguiseBooth->HidingPlayers.Add(PC->MyFortPawn);
				Inventory::GiveItem(PC, AGID, 1);
			}
		}
		else if (auto KeycardLock = ReceivingActor->Cast<ABGA_Athena_Keycard_Lock_Parent_C>())
		{
			auto Key = PC->WorldInventory->Inventory.ReplicatedEntries.Search([KeycardLock](FFortItemEntry &Entry)
																			  { return Entry.ItemDefinition == KeycardLock->KeyID; });
			if (Key)
				Inventory::Remove(PC, Key->ItemGuid);
		}
		/*else if (auto GasPump = ReceivingActor->Cast<AApollo_GasPump_Valet_C>()) {
			auto Pump = FindObject<UFortWeaponRangedItemDefinition>("/Game/Athena/Items/Weapons/Prototype/PetrolPump/WID_Petrol_Pump.WID_Petrol_Pump");
			auto Item = GiveItem(PC, Pump, 1, 69696);
			ServerExecuteInventoryItemHook(PC, Item->ItemEntry.ItemGuid);
			PC->ClientEquipItem(Item->ItemEntry.ItemGuid, true);
		}*/
		// todo: fix
		else if (auto PetrolCan = ReceivingActor->Cast<ABGA_Petrol_Pickup_C>())
		{
			auto Pump = Utils::FindObject<UFortWeaponRangedItemDefinition>("/Game/Athena/Items/Weapons/Prototype/WID_Launcher_Petrol.WID_Launcher_Petrol");
			InternalPickup(PC, *Inventory::MakeItemEntry(Pump, 1, -1));
		}
		else if (auto UpgradeBench = ReceivingActor->Cast<AB_Athena_Wumba_C>())
		{
			static auto UT = Utils::FindObject<UDataTable>("/Game/Items/Datatables/AthenaWumbaData.AthenaWumbaData");
			auto Direction = InteractionBeingAttempted == EInteractionBeingAttempted::SecondInteraction ? EFortWeaponUpgradeDirection::Horizontal : EFortWeaponUpgradeDirection::Vertical;

			FWeaponUpgradeItemRow *Row = nullptr;
			for (auto &[Pair, Val] : (TMap<FName, FWeaponUpgradeItemRow *>)UT->RowMap)
			{
				if (Val->CurrentWeaponDef == PC->MyFortPawn->CurrentWeapon->WeaponData && Val->Direction == Direction)
				{
					Row = Val;
					break;
				}
			}

			auto WoodCost = CostMap[uint32(Row->WoodCost)];
			auto StoneCost = CostMap[uint32(Row->BrickCost)];
			auto MetalCost = CostMap[uint32(Row->MetalCost)];

			LateGameInternal::Guns Guns;
			auto WoodEntry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([Guns](FFortItemEntry &Entry)
																					{ return Entry.ItemDefinition == Guns.Wood; });
			auto StoneEntry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([Guns](FFortItemEntry &Entry)
																					 { return Entry.ItemDefinition == Guns.Stone; });
			auto MetalEntry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([Guns](FFortItemEntry &Entry)
																					 { return Entry.ItemDefinition == Guns.Metal; });

			WoodEntry->Count -= WoodCost;
			if (WoodEntry->Count <= 0)
				Inventory::Remove(PC, WoodEntry->ItemGuid);
			Inventory::ReplaceEntry(PC, *WoodEntry);

			StoneEntry->Count -= StoneCost;
			if (StoneEntry->Count <= 0)
				Inventory::Remove(PC, StoneEntry->ItemGuid);
			Inventory::ReplaceEntry(PC, *StoneEntry);

			MetalEntry->Count -= MetalCost;
			if (MetalEntry->Count <= 0)
				Inventory::Remove(PC, MetalEntry->ItemGuid);
			Inventory::ReplaceEntry(PC, *MetalEntry);

			auto IE = PC->WorldInventory->Inventory.ReplicatedEntries.Search([PC](FFortItemEntry &Entry)
																			 { return Entry.ItemGuid == PC->MyFortPawn->CurrentWeapon->ItemEntryGuid; });
			Inventory::Remove(PC, IE->ItemGuid);
			Inventory::GiveItem(PC, *Inventory::MakeItemEntry(Row->UpgradedWeaponDef, 1, 0));
		}

		if (auto Chest = ReceivingActor->Cast<ATiered_Chest_Athena_C>())
		{
			static auto Name = UKismetStringLibrary::Conv_StringToName(L"Loot_AthenaTreasure");
			if (Chest->SearchLootTierGroup == Name)
			{
				auto PS = PC->PlayerState->Cast<AFortPlayerStateAthena>();
				PS->NumChestsOpened++;
				const char *AccoladePath = nullptr;
				switch (PS->NumChestsOpened)
				{
				case 3:
					AccoladePath = "/Game/Athena/Items/Accolades/AccoladeId_008_SearchChests_Bronze.AccoladeId_008_SearchChests_Bronze";
					break;
				case 7:
					AccoladePath = "/Game/Athena/Items/Accolades/AccoladeId_009_SearchChests_Silver.AccoladeId_009_SearchChests_Silver";
					break;
				case 12:
					AccoladePath = "/Game/Athena/Items/Accolades/AccoladeId_010_SearchChests_Gold.AccoladeId_010_SearchChests_Gold";
					break;
				default:
					break;
				}

				if (AccoladePath)
				{
					auto Accolade = Utils::FindObject<UFortAccoladeItemDefinition>(AccoladePath);
					XP::GiveAccolade(PC, Accolade);
				}
			}
		}
		if (auto BuildingActor = ReceivingActor->Cast<ABuildingActor>())
		{
			FGameplayTagContainer SourceTags;
			FGameplayTagContainer ContextTags;
			FGameplayTagContainer TargetTags = BuildingActor->StaticGameplayTags;

			auto QuestManager = PC->GetQuestManager(ESubGame::Athena);
			if (QuestManager)
			{
				QuestManager->GetSourceAndContextTags(&SourceTags, &ContextTags);

				XP::SendStatEvent(QuestManager, BuildingActor, SourceTags, TargetTags, nullptr, nullptr, 1, EFortQuestObjectiveStatEvent::Interact);
			}
		}
	}

	static inline void (*GetPlayerViewPointOG)(AFortPlayerController *PC, FVector &Loc, FRotator &Rot);
	static void GetPlayerViewPoint(AFortPlayerController *PC, FVector &Loc, FRotator &Rot)
	{
		static auto Spec = UKismetStringLibrary::Conv_StringToName(L"Spectating");
		if (PC->StateName.ComparisonIndex == Spec.ComparisonIndex)
		{
			Loc = PC->LastSpectatorSyncLocation;
			Rot = PC->LastSpectatorSyncRotation;
		}
		else if (PC->GetViewTarget())
		{
			Loc = PC->GetViewTarget()->K2_GetActorLocation();
			Rot = PC->GetControlRotation();
		}
		else
		{
			return GetPlayerViewPointOG(PC, Loc, Rot);
		}
	}

	static void ServerAttemptInventoryDrop(AFortPlayerControllerAthena *PC, FGuid Guid, int32 Count, bool bTrash)
	{
		if (!PC)
			return;
		auto itemEntry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([Guid](FFortItemEntry &entry)
																				{ return entry.ItemGuid == Guid; });
		if (!itemEntry || (itemEntry->Count - Count) < 0)
			return;
		itemEntry->Count -= Count;
		Inventory::SpawnPickup(PC->Pawn->K2_GetActorLocation() + PC->Pawn->GetActorForwardVector() * 70.f + FVector(0, 0, 50), *itemEntry, EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::Unset, PC->MyFortPawn, Count);
		if (itemEntry->Count == 0)
			Inventory::Remove(PC, Guid);
		else
			Inventory::ReplaceEntry(PC, *itemEntry);
		return;
	}

	static inline void (*ClientOnPawnDiedOG)(AFortPlayerControllerAthena *PC, FFortPlayerDeathReport &DeathReport);
	static void ClientOnPawnDied(AFortPlayerControllerAthena *PC, FFortPlayerDeathReport &DeathReport)
	{
		if (!PC)
			return ClientOnPawnDiedOG(PC, DeathReport);
		auto GS = AFortGameStateAthena::Get();
		auto GM = AFortGameModeAthena::Get();

		auto PlayerState = (AFortPlayerStateAthena *)PC->PlayerState;
		if (!GS->IsRespawningAllowed(PlayerState) && PC->WorldInventory)
		{
			for (auto &entry : PC->WorldInventory->Inventory.ReplicatedEntries)
			{
				if (!entry.ItemDefinition->IsA<UFortWeaponMeleeItemDefinition>() && (entry.ItemDefinition->IsA<UFortWeaponRangedItemDefinition>() || entry.ItemDefinition->IsA<UFortConsumableItemDefinition>() || entry.ItemDefinition->IsA<UFortAmmoItemDefinition>()))
				{
					Inventory::SpawnPickup(PC->MyFortPawn->K2_GetActorLocation(), entry, EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::PlayerElimination, PC->MyFortPawn);
				}
			}
			static LateGameInternal::Guns LGGuns;
			Inventory::SpawnPickup(PC->MyFortPawn->K2_GetActorLocation(), *Inventory::MakeItemEntry((UFortWorldItemDefinition *)LGGuns.Wood, 50, 0), EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::PlayerElimination, PC->MyFortPawn);
			Inventory::SpawnPickup(PC->MyFortPawn->K2_GetActorLocation(), *Inventory::MakeItemEntry((UFortWorldItemDefinition *)LGGuns.Stone, 50, 0), EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::PlayerElimination, PC->MyFortPawn);
			Inventory::SpawnPickup(PC->MyFortPawn->K2_GetActorLocation(), *Inventory::MakeItemEntry((UFortWorldItemDefinition *)LGGuns.Metal, 50, 0), EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::PlayerElimination, PC->MyFortPawn);
		}

		auto KillerPS = (AFortPlayerStateAthena *)DeathReport.KillerPlayerState;
		if (DeathReport.KillerPlayerState && DeathReport.KillerPawn && DeathReport.KillerPawn->Controller->IsA<AFortPlayerControllerAthena>() && DeathReport.KillerPawn->Controller != PC)
		{
			KillerPS->KillScore++;
			KillerPS->OnRep_Kills();
			KillerPS->TeamKillScore++;
			KillerPS->OnRep_TeamKillScore();

			KillerPS->ClientReportKill(PlayerState);

			auto KillerPC = (AFortPlayerControllerAthena *)KillerPS->Owner;

			if (KillerPC && KillerPC->MatchReport)
				KillerPC->MatchReport->MatchStats.Stats[3] = KillerPS->KillScore;
		}

		PlayerState->PawnDeathLocation = PC->MyFortPawn->K2_GetActorLocation();

		PlayerState->DeathInfo.bDBNO = PC->MyFortPawn->bWasDBNOOnDeath;
		PlayerState->DeathInfo.DeathLocation = PC->MyFortPawn->K2_GetActorLocation();
		PlayerState->DeathInfo.DeathTags = DeathReport.Tags;
		PlayerState->DeathInfo.DeathCause = AFortPlayerStateAthena::ToDeathCause(DeathReport.Tags, PC->MyFortPawn->bWasDBNOOnDeath);
		if (PlayerState->DeathInfo.bDBNO)
			PlayerState->DeathInfo.Downer = KillerPS;
		PlayerState->DeathInfo.FinisherOrDowner = KillerPS;
		PlayerState->DeathInfo.Distance = DeathReport.KillerPawn ? DeathReport.KillerPawn->GetDistanceTo(PC->MyFortPawn) : PC->MyFortPawn->Cast<AFortPlayerPawnAthena>()->LastFallDistance;
		PlayerState->DeathInfo.bInitialized = true;
		PlayerState->OnRep_DeathInfo();

		if (!GS->IsRespawningAllowed(PlayerState) && !PC->MyFortPawn->IsDBNO())
		{
			FAthenaRewardResult Result;
			Result.TotalBookXpGained = PC->XPComponent->TotalXpEarned;
			Result.TotalSeasonXpGained = PC->XPComponent->TotalXpEarned;
			PC->ClientSendEndBattleRoyaleMatchForPlayer(true, Result);

			PlayerState->Place = GS->PlayersLeft;
			PlayerState->OnRep_Place();

			FAthenaMatchStats Stats = PC->MatchReport->MatchStats;
			FAthenaMatchTeamStats TeamStats = PC->MatchReport->TeamStats;

			// Stats.Stats[3] = PlayerState->KillScore;
			// Stats.Stats[8] = PlayerState->SquadId;
			PC->ClientSendMatchStatsForPlayer(Stats);

			TeamStats.Place = PlayerState->Place;
			TeamStats.TotalPlayers = GS->TotalPlayers;
			PC->ClientSendTeamStatsForPlayer(TeamStats);

			((void (*)(AFortGameModeAthena *, AFortPlayerControllerAthena *, APlayerState *, AFortPlayerPawn *, UFortWeaponItemDefinition *, EDeathCause, char))(ImageBase + 0x1ec8680))(GM, PC, KillerPS, (AFortPlayerPawnAthena *)DeathReport.KillerPawn, (DeathReport.KillerPawn && DeathReport.KillerPawn->CurrentWeapon) ? DeathReport.KillerPawn->CurrentWeapon->WeaponData : nullptr, PlayerState->DeathInfo.DeathCause, 0);

			if (KillerPS && DeathReport.KillerPawn && DeathReport.KillerPawn != PC->MyFortPawn && !DeathReport.KillerPawn->IsA<ABP_MangPlayerPawn_Parent_C>())
			{
				FGameplayTagContainer SourceTags;
				FGameplayTagContainer ContextTags;
				FGameplayTagContainer TargetTags = PC->MyFortPawn->GameplayTags;

				auto QuestManager = ((AFortPlayerController*)DeathReport.KillerPawn->Controller)->GetQuestManager(ESubGame::Athena);

				QuestManager->GetSourceAndContextTags(&SourceTags, &ContextTags);

				XP::SendStatEvent(QuestManager, PC->MyFortPawn, SourceTags, TargetTags, nullptr, nullptr, 1, EFortQuestObjectiveStatEvent::Kill);

				auto Handle = KillerPS->AbilitySystemComponent->MakeEffectContext();
				FGameplayTag Tag;
				static auto Cue = UKismetStringLibrary::Conv_StringToName(L"GameplayCue.Shield.PotionConsumed");
				Tag.TagName = Cue;
				KillerPS->AbilitySystemComponent->NetMulticast_InvokeGameplayCueAdded(Tag, FPredictionKey(), Handle);
				KillerPS->AbilitySystemComponent->NetMulticast_InvokeGameplayCueExecuted(Tag, FPredictionKey(), Handle);

				auto Health = DeathReport.KillerPawn->GetHealth();
				auto Shield = DeathReport.KillerPawn->GetShield();

				if (Health == 100)
				{
					Shield += Shield + 50;
				}
				else if (Health + 50 > 100)
				{
					Health = 100;
					Shield += (Health + 50) - 100;
				}
				else if (Health + 50 <= 100)
				{
					Health += 50;
				}

				DeathReport.KillerPawn->SetHealth(UKismetMathLibrary::FClamp(Health, 0, 100));
				DeathReport.KillerPawn->SetShield(UKismetMathLibrary::FClamp(Shield, 0, 100));
			}
			if (KillerPS && KillerPS->Place == 1)
			{
				FGameplayTagContainer SourceTags;
				FGameplayTagContainer ContextTags;
				FGameplayTagContainer TargetTags = PC->MyFortPawn->GameplayTags;

				auto QuestManager = ((AFortPlayerController*)DeathReport.KillerPawn->Controller)->GetQuestManager(ESubGame::Athena);

				QuestManager->GetSourceAndContextTags(&SourceTags, &ContextTags);

				XP::SendStatEvent(QuestManager, DeathReport.KillerPawn->Controller, SourceTags, TargetTags, nullptr, nullptr, 1, EFortQuestObjectiveStatEvent::Win);

				// GiveAccolade(DeathReport.KillerPawn->Controller->Cast<AFortPlayerControllerAthena>(), Utils::FindObject<UFortAccoladeItemDefinition>("/Game/Athena/Items/Accolades/AccoladeId_001_Victory.AccoladeId_001_Victory"));
				auto KillerWeapon = DeathReport.KillerPawn ? DeathReport.KillerPawn->CurrentWeapon ? DeathReport.KillerPawn->CurrentWeapon->WeaponData : nullptr : nullptr;

				auto KillerPC = (AFortPlayerControllerAthena *)KillerPS->Owner;
				if (KillerWeapon)
				{
					KillerPC->PlayWinEffects(DeathReport.KillerPawn, KillerWeapon, PlayerState->DeathInfo.DeathCause, false);
					KillerPC->ClientNotifyWon(DeathReport.KillerPawn, KillerWeapon, PlayerState->DeathInfo.DeathCause);
				}

				FAthenaRewardResult KResult = KillerPC->MatchReport->EndOfMatchResults;
				KResult.TotalBookXpGained = KillerPC->XPComponent->TotalXpEarned;
				KResult.TotalSeasonXpGained = KillerPC->XPComponent->TotalXpEarned;
				KillerPC->ClientSendEndBattleRoyaleMatchForPlayer(true, KResult);

				FAthenaMatchStats KStats = PC->MatchReport->MatchStats;
				FAthenaMatchTeamStats KTeamStats = PC->MatchReport->TeamStats;

				KillerPC->ClientSendMatchStatsForPlayer(KStats);

				KTeamStats.Place = KillerPS->Place;
				KTeamStats.TotalPlayers = GS->TotalPlayers;
				KillerPC->ClientSendTeamStatsForPlayer(KTeamStats);

				GS->WinningTeam = KillerPS->TeamIndex;
				GS->OnRep_WinningTeam();
				GS->WinningPlayerState = KillerPS;
				GS->OnRep_WinningPlayerState();
			}
		}

		return ClientOnPawnDiedOG(PC, DeathReport);
	}

	static inline void (*NetMulticast_Athena_BatchedDamageCuesOG)(AFortPawn *Pawn, FAthenaBatchedDamageGameplayCues_Shared SharedData, FAthenaBatchedDamageGameplayCues_NonShared NonSharedData);
	static void NetMulticast_Athena_BatchedDamageCues(AFortPlayerPawnAthena *Pawn, FAthenaBatchedDamageGameplayCues_Shared SharedData, FAthenaBatchedDamageGameplayCues_NonShared NonSharedData)
	{
		if (!Pawn || !Pawn->Controller || !Pawn->CurrentWeapon || Pawn->Controller->IsA<AFortAthenaAIBotController>())
			return NetMulticast_Athena_BatchedDamageCuesOG(Pawn, SharedData, NonSharedData);

		NetMulticast_Athena_BatchedDamageCuesOG(Pawn, SharedData, NonSharedData);
		AFortInventory *Inventory = nullptr;
		if (Pawn->CurrentWeapon)
		{
			auto ent = ((AFortPlayerControllerAthena *)Pawn->Controller)->WorldInventory->Inventory.ReplicatedEntries.Search([Pawn](FFortItemEntry &entry)
																															 { return entry.ItemGuid == Pawn->CurrentWeapon->ItemEntryGuid; });
			if (ent)
			{
				ent->LoadedAmmo = Pawn->CurrentWeapon->AmmoCount;
				if ((ent->ItemDefinition->Cast<UFortWeaponItemDefinition>()->bUsesPhantomReserveAmmo && Pawn->CurrentWeapon->PhantomReserveAmmo == 0) || (Inventory::GetStats(Pawn->CurrentWeapon->WeaponData)->ClipSize == 0 && ent->LoadedAmmo <= 0 && !ent->ItemDefinition->IsA<UFortWeaponMeleeItemDefinition>()))
				{
					Inventory::Remove((AFortPlayerControllerAthena *)Pawn->Controller, ent->ItemGuid);
				}
				Inventory::ReplaceEntry((AFortPlayerControllerAthena *)Pawn->Controller, *ent);
			}
		}
	}

	static void ReloadWeapon(AFortWeapon *Weapon, int AmmoToRemove)
	{
		AFortPlayerControllerAthena *PC = (AFortPlayerControllerAthena *)((AFortPlayerPawnAthena *)Weapon->Owner)->Controller;
		AFortInventory *Inventory;
		if (auto Bot = PC->Cast<AFortAthenaAIBotController>())
		{
			Inventory = Bot->Inventory;
		}
		else
		{
			Inventory = PC->WorldInventory;
		}
		if (!PC || !Inventory || !Weapon)
			return;
		if (Weapon->WeaponData->bUsesPhantomReserveAmmo)
		{
			Weapon->PhantomReserveAmmo -= AmmoToRemove;
			Weapon->OnRep_PhantomReserveAmmo();
		}
		auto Ammo = Weapon->WeaponData->GetAmmoWorldItemDefinition_BP();
		auto ent = Inventory->Inventory.ReplicatedEntries.Search([Ammo](FFortItemEntry &entry)
																 { return entry.ItemDefinition == Ammo; });
		auto WeaponEnt = Inventory->Inventory.ReplicatedEntries.Search([Weapon](FFortItemEntry &entry)
																	   { return entry.ItemGuid == Weapon->ItemEntryGuid; });
		if (!WeaponEnt || !WeaponEnt->ItemDefinition)
			return;
		if (ent && !Weapon->WeaponData->bUsesPhantomReserveAmmo && !Weapon->WeaponData->WeaponRechargeAmmoQuantity.Curve.CurveTable)
		{
			ent->Count -= AmmoToRemove;
			if (ent->Count <= 0)
			{
				Inventory::Remove(PC, ent->ItemGuid);
			}
			Inventory::ReplaceEntry(PC, *ent);
			if (ent->Count > 0)
			{
				WeaponEnt->LoadedAmmo += AmmoToRemove;
				Inventory::ReplaceEntry(PC, *WeaponEnt);
			}
		}
	}

	static void ServerPlayEmoteItem(AFortPlayerControllerAthena *PC, UFortMontageItemDefinitionBase *EmoteAsset, float EmoteRandomNumber)
	{
		if (!PC || !EmoteAsset || !PC->MyFortPawn)
			return;
		auto ASC = ((AFortPlayerStateAthena *)PC->PlayerState)->AbilitySystemComponent;

		FGameplayAbilitySpec NewSpec;
		UGameplayAbility *Ability = nullptr;
		if (auto Spray = EmoteAsset->Cast<UAthenaSprayItemDefinition>())
		{
			Ability = (UGameplayAbility *)UObject::FindClassFast("GAB_Spray_Generic_C")->DefaultObject;
		}
		else if (auto Toy = EmoteAsset->Cast<UAthenaToyItemDefinition>())
		{
			Ability = (UGameplayAbility *)Toy->ToySpawnAbility->DefaultObject;
		}
		else if (auto Emote = EmoteAsset->Cast<UAthenaDanceItemDefinition>())
		{
			auto DA = Emote->CustomDanceAbility.Get();
			Ability = DA ? (UGameplayAbility *)DA->DefaultObject : (UGameplayAbility *)UObject::FindClassFast("GAB_Emote_Generic_C")->DefaultObject;
			PC->MyFortPawn->bMovingEmote = Emote->bMovingEmote;
			PC->MyFortPawn->bMovingEmoteForwardOnly = Emote->bMoveForwardOnly;
			PC->MyFortPawn->EmoteWalkSpeed = Emote->WalkForwardSpeed;
		}

		if (Ability)
		{
			((void (*)(FGameplayAbilitySpec *, UGameplayAbility *, int, int, UObject *))ConstructAbilitySpec)(&NewSpec, Ability, 1, -1, EmoteAsset);
			FGameplayAbilitySpecHandle handle;
			((void (*)(UFortAbilitySystemComponent *, FGameplayAbilitySpecHandle *, FGameplayAbilitySpec *, void *))(ImageBase + 0x9a5f70))(ASC, &handle, &NewSpec, nullptr);
		}
	}

	static inline void (*MovingEmoteStoppedOG)(AFortPlayerPawnAthena *Pawn);
	static void MovingEmoteStopped(AFortPlayerPawnAthena *Pawn)
	{
		if (!Pawn)
			return MovingEmoteStoppedOG(Pawn);
		Pawn->bMovingEmote = false;
		Pawn->bMovingEmoteForwardOnly = false;
		return MovingEmoteStoppedOG(Pawn);
	}

	static void ServerReturnToMainMenu(AFortPlayerController *PC)
	{
		PC->ClientReturnToMainMenu(L"");
	}

	static inline AActor *(*SpawnToyInstanceOG)(UObject *Context, FFrame &Stack, AActor **Ret);
	static AActor *SpawnToyInstance(UObject *Context, FFrame &Stack, AActor **Ret)
	{
		Utils::Log("call");
		TSubclassOf<class AActor> ToyClass;
		FTransform SpawnPosition;
		Stack.StepCompiledIn(&ToyClass);
		Stack.StepCompiledIn(&SpawnPosition);

		SpawnToyInstanceOG(Context, Stack, Ret);
		auto PC = (AFortPlayerControllerAthena *)Context;
		auto Actor = Utils::SpawnActor(ToyClass.Get(), SpawnPosition, PC);

		PC->ActiveToyInstances.Add(Actor);
		for (auto &[Key, Val] : PC->ToySummonCounts)
		{
			if (Key == ToyClass)
			{
				Val++;
				break;
			}
		}

		*Ret = Actor;
		return Actor;
	}

	static void ServerCheat(AFortPlayerControllerAthena *PC, FString FCommand)
	{
		auto Command = FCommand.ToString();
		auto GS = AFortGameStateAthena::Get();
		auto GM = AFortGameModeAthena::Get();
		if (Command == "startbus" && GS->GamePhase < EAthenaGamePhase::Aircraft)
		{
			((void (*)(AGameModeBase *, int))(ImageBase + 0x1ed5710))(GM, 0);
			GameMode::startedBus = true;
		}
		else if (Command.starts_with("spawnactor "))
		{
			auto Loc = PC->Pawn->K2_GetActorLocation();
			Loc.Z += 500.f;
			auto ClassOrPath = Command.substr(11);
			auto Class = Utils::FindObject<UClass>(ClassOrPath);
			if (!Class)
				Class = UObject::FindClassFast(ClassOrPath.c_str());
			if (!Class)
				Class = UObject::FindClass(ClassOrPath.c_str());
			if (Class)
				Utils::SpawnActor(Class, Loc);
		}
		else if (Command.starts_with("loadlevel "))
		{
			auto Loc = PC->Pawn->K2_GetActorLocation();
			Loc.Z += 500.f;
			auto Path_ = Command.substr(10);
			auto Path = wstring(Path_.begin(), Path_.end());
			ULevelStreamingDynamic::LoadLevelInstance(UWorld::Get(), Path.c_str(), Loc, FRotator(), nullptr, FString());
		}
		else if (Command.starts_with("internal "))
		{
			auto Cmd_ = Command.substr(9);
			auto Cmd = wstring(Cmd_.begin(), Cmd_.end());
			UKismetSystemLibrary::ExecuteConsoleCommand(UWorld::Get(), Cmd.c_str(), nullptr);
		}
		else if (Command.starts_with("spawnpickup "))
		{
			auto WeaponName = Command.substr(12);
			auto Weapon = Utils::FindObject<UFortWeaponRangedItemDefinition>(WeaponName);
			Inventory::SpawnPickup(PC->Pawn->K2_GetActorLocation(), Weapon, 1, 0, EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource::Unset, PC->MyFortPawn, false);
		}
		else if (Command.starts_with("getquesttags"))
		{
			FGameplayTagContainer SourceTags;
			FGameplayTagContainer ContextTags;
			FGameplayTagContainer PlaylistContextTags;

			PC->GetQuestManager(ESubGame::Athena)->GetSourceAndContextTags(&SourceTags, &ContextTags);
			PlaylistContextTags = AFortGameStateAthena::Get()->CurrentPlaylistInfo.BasePlaylist->GameplayTagContainer;

			for (auto &Tag : SourceTags.GameplayTags)
				Utils::Log("SourceTags GameplayTag: " + Tag.TagName.ToString());

			for (auto &Tag : SourceTags.ParentTags)
				Utils::Log("SourceTags ParentTag: " + Tag.TagName.ToString());

			for (auto &Tag : ContextTags.GameplayTags)
				Utils::Log("ContextTags GameplayTag: " + Tag.TagName.ToString());

			for (auto &Tag : ContextTags.ParentTags)
				Utils::Log("ContextTags ParentTag: " + Tag.TagName.ToString());

			for (auto &Tag : PlaylistContextTags.GameplayTags)
				Utils::Log("PlaylistContextTags GameplayTag: " + Tag.TagName.ToString());

			for (auto &Tag : PlaylistContextTags.ParentTags)
				Utils::Log("PlaylistContextTags ParentTag: " + Tag.TagName.ToString());
		}
	}

public:
	static void HookFunctions()
	{
		Utils::Hook<AFortPlayerControllerAthena>(ServerAcknowledgePossessionVft, ServerAcknowledgePossessionHook, ServerAcknowledgePossessionOG);
		Utils::Hook<AFortPlayerControllerAthena>(ServerExecuteInventoryItemVft, ServerExecuteInventoryItemHook);
		Utils::Hook<AFortPlayerControllerAthena>(uint32(0x21d), ServerAttemptInventoryDrop);
		Utils::Hook<AFortPlayerPawnAthena>(0x1F0, ServerHandlePickupInfo, ServerHandlePickupInfoOG);
		Utils::Hook<AFortPlayerPawnAthena>(ServerSendZiplineStateVft, ServerSendZiplineState);
		Utils::Hook<AFortPlayerControllerAthena>(uint32(0x4FA), ServerClientIsReadyToRespawn);
		Utils::Hook<AFortPlayerControllerAthena>(uint32(0x265), ServerReturnToMainMenu);
		Utils::Hook<AFortPlayerControllerAthena>(uint32(0x1c9), ServerPlayEmoteItem);
		Utils::Hook<AFortPlayerControllerAthena>(uint32(0x1c7), ServerCheat);
		Utils::Hook<AFortPlayerPawnAthena>(uint32(0x243), RetFalse); // shakedown, delete when fixed - ploosh
		Utils::Hook<AFortPlayerPawnAthena>(uint32(0x119), NetMulticast_Athena_BatchedDamageCues, NetMulticast_Athena_BatchedDamageCuesOG);
		Utils::Hook<UFortControllerComponent_Aircraft>(ServerAttemptAircraftJumpVft, ServerAttemptAircraftJumpHook);
		Utils::Hook<UFortControllerComponent_Interaction>(uint32(0x8b), ServerAttemptInteract, ServerAttemptInteractOG);
		Utils::Hook(DispatchRequest, DispatchRequestHook, DispatchRequestOG);
		Utils::Hook(ImageBase + 0x295b660, GetPlayerViewPoint, GetPlayerViewPointOG);
		Utils::Hook(ImageBase + 0x308dc10, ClientOnPawnDied, ClientOnPawnDiedOG);
		Utils::Hook(ImageBase + 0x261d8e0, CompletePickupAnimation, CompletePickupAnimationOG);
		Utils::Hook(ImageBase + 0x9f25a0, MovingEmoteStopped, MovingEmoteStoppedOG);
		Utils::Hook(ImageBase + 0x2ca3e80, ReloadWeapon);
		Utils::Hook(ImageBase + 0x290ca00, OnCapsuleBeginOverlap, OnCapsuleBeginOverlapOG);
		Utils::ExecHook(Utils::FindObject<UFunction>("/Script/FortniteGame.FortPlayerController.SpawnToyInstance"), SpawnToyInstance, SpawnToyInstanceOG);
	}
};