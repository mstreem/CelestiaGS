#pragma once
#include "pch.h"
#include "LateGame.h"
#include "Bots.h"
#include "Defs.h"

class Misc
{
	static int GetNetMode()
	{
		return 1;
	}

	static inline void (*SetDynamicFoundationEnabledOG)(UObject *, FFrame &);
	static void SetDynamicFoundationEnabled(UObject *Context, FFrame &Stack)
	{
		bool bEnabled;
		Stack.StepCompiledIn(&bEnabled);
		auto Foundation = (ABuildingFoundation *)Context;
		Foundation->DynamicFoundationRepData.EnabledState = bEnabled ? EDynamicFoundationEnabledState::Enabled : EDynamicFoundationEnabledState::Disabled;
		Foundation->OnRep_DynamicFoundationRepData();
		Foundation->FoundationEnabledState = bEnabled ? EDynamicFoundationEnabledState::Enabled : EDynamicFoundationEnabledState::Disabled;
		return SetDynamicFoundationEnabledOG(Context, Stack);
	}

	static inline void (*SetDynamicFoundationTransformOG)(UObject *Context, FFrame &Stack);
	static void SetDynamicFoundationTransform(UObject *Context, FFrame &Stack)
	{
		FTransform Transform;
		Stack.StepCompiledIn(&Transform);

		auto Rotation = Transform.Rotation.Rotator();
		auto Location = Transform.Translation;
		auto Foundation = (ABuildingFoundation *)Context;
		Foundation->DynamicFoundationTransform = Transform;
		Foundation->StreamingData.FoundationLocation = Location;
		Foundation->DynamicFoundationRepData.Rotation = Rotation;
		Foundation->DynamicFoundationRepData.Translation = Location;
		Foundation->OnRep_DynamicFoundationRepData();
		if (Foundation->GetName() == "Fortilla_Foundation_MANG")
		{
			for (auto &World : Foundation->AdditionalWorlds)
			{
				ULevelStreamingDynamic::LoadLevelInstanceBySoftObjectPtr(UWorld::Get(), World, Location, Rotation, nullptr, FString());
			}
		}
		return SetDynamicFoundationTransformOG(Context, Stack);
	}

	static inline void (*StartNewSafeZonePhaseOG)(AFortGameModeAthena *GM, int a2);
	static void StartNewSafeZonePhaseHook(AFortGameModeAthena *GM, int a2)
	{
		auto GS = AFortGameStateAthena::Get();
		auto SZD = &GS->MapInfo->SafeZoneDefinition;
		auto Durations = *(TArray<float> *)(__int64(SZD) + 0x1F8);
		auto HoldDurations = *(TArray<float> *)(__int64(SZD) + 0x1E8);
		static bool bSetupDurations = false;

		if (!bSetupDurations)
		{
			bSetupDurations = true;

			auto GameData = GS->CurrentPlaylistInfo.BasePlaylist->GameData.Get();
			if (!GameData)
				GameData = Utils::FindObject<UCurveTable>("/Game/Balance/AthenaGameData.AthenaGameData");

			auto ShrinkTime = UKismetStringLibrary::Conv_StringToName(L"Default.SafeZone.ShrinkTime");
			auto HoldTime = UKismetStringLibrary::Conv_StringToName(L"Default.SafeZone.WaitTime");

			if (LateGame)
			{
				array<float, 8> LDDurations{
					0.f,
					65.f,
					60.f,
					50.f,
					45.f,
					35.f,
					30.f,
					40.f,
				};
				array<float, 8> LDHDurations{
					0.f,
					60.f + 11.f,
					55.f,
					50.f,
					45.f,
					30.f,
					0.f,
					0.f,
				};
				int i = 0;
				for (auto &Duration : Durations)
				{
					Duration = LDDurations[i];
					i++;
				}
				i = 0;
				for (auto &Duration : HoldDurations)
				{
					Duration = LDHDurations[i];
					i++;
				}
			}
			else
			{
				int i = 0;
				for (auto &Duration : Durations)
				{
					UDataTableFunctionLibrary::EvaluateCurveTableRow(GameData, ShrinkTime, i, nullptr, &Durations[i], FString());
					i++;
				}
				i = 0;
				for (auto &Duration : HoldDurations)
				{
					UDataTableFunctionLibrary::EvaluateCurveTableRow(GameData, HoldTime, i, nullptr, &HoldDurations[i], FString());
					i++;
				}
			}

			if (LateGame)
			{
				GM->SafeZonePhase = 2;
				auto Bus = GS->Aircrafts[0];
				GM->SafeZoneIndicator->NextCenter = Bus->FlightInfo.FlightStartLocation;
				GM->SafeZoneIndicator->NextNextCenter = Bus->FlightInfo.FlightStartLocation;
			}
		}

		auto& Duration = Durations[LateGame ? GM->SafeZonePhase - 2 : GM->SafeZonePhase + 1];
		auto& HoldDuration = HoldDurations[LateGame ? GM->SafeZonePhase - 2 : GM->SafeZonePhase + 1];
		if (!LateGame && GM->SafeZonePhase % 2)
		{
			for (auto& PC : GM->AlivePlayers)
			{
				FGameplayTagContainer SourceTags;
				FGameplayTagContainer ContextTags;
				FGameplayTagContainer TargetTags;

				auto QuestManager = PC->GetQuestManager(ESubGame::Athena);

				QuestManager->GetSourceAndContextTags(&SourceTags, &ContextTags);

				XP::SendStatEvent(QuestManager, nullptr, SourceTags, TargetTags, nullptr, nullptr, 1, EFortQuestObjectiveStatEvent::StormPhase);
			}
		}

		GM->SafeZoneIndicator->SafeZoneStartShrinkTime = UGameplayStatics::GetTimeSeconds(UWorld::Get()) + HoldDuration;
		GM->SafeZoneIndicator->SafeZoneFinishShrinkTime = GM->SafeZoneIndicator->SafeZoneStartShrinkTime + Duration;

		return StartNewSafeZonePhaseOG(GM, a2);
	}

	static void RemoveGadget(AFortPlayerControllerAthena *PC, UFortWorldItem *Item)
	{
		Inventory::Remove(PC, Item->ItemEntry.ItemGuid);
		// todo: fix
		auto AS = ((UFortGadgetItemDefinition *)Item->ItemEntry.ItemDefinition)->AbilitySet;
		for (auto &Eff : AS->GrantedGameplayEffects)
		{
			for (auto &Effect : PC->MyFortPawn->AbilitySystemComponent->ActiveGameplayEffects.GameplayEffects_Internal)
			{
				if (Effect.Spec.Def->IsA(Eff.GameplayEffect.Get()))
				{
					PC->MyFortPawn->AbilitySystemComponent->RemoveActiveEffectsWithTags(Effect.Spec.DynamicGrantedTags);
				}
			}
		}
	}

	static inline __int64 (*OnExplodedOG)(AFortProjectileBase *Projectile, TArray<class AActor *> &HitActors, TArray<struct FHitResult> &HitResults);
	static __int64 OnExploded(AFortProjectileBase *Projectile, TArray<class AActor *> &HitActors, TArray<struct FHitResult> &HitResults)
	{
		if (auto Consumable = Projectile->Cast<AB_Prj_Athena_Consumable_Thrown_C>())
		{
			if (Consumable->ItemDefinition->IsA<UFortWorldItemDefinition>())
			{
				auto PC = (AFortPlayerControllerAthena *)Projectile->GetOwnerPlayerController();
				auto Pickup = Inventory::SpawnPickup(Consumable->K2_GetActorLocation(), Consumable->ItemDefinition, 1, 0, EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource::Unset, PC->MyFortPawn, false);
				if (Pickup)
				{
					Consumable->Pickup = Pickup;
					Consumable->OnRep_Pickup();
				}
			}
		}
		return OnExplodedOG(Projectile, HitActors, HitResults);
	}

	static inline __int64 (*ApplyCostOG)(UGameplayAbility *, void *, void *, void *);
	static __int64 ApplyCost(UFortGameplayAbility *GA, void *a2, void *a3, void *a4)
	{
		if (GA->GetName().starts_with("GA_Athena_AppleSun_Passive_C_"))
		{
			auto Def = Utils::FindObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/AppleSun/WID_Athena_AppleSun.WID_Athena_AppleSun");
			auto ASC = GA->GetActivatingAbilityComponent();
			AFortPlayerStateAthena *PS = (AFortPlayerStateAthena *)ASC->GetOwner();
			auto Pawn = PS->GetCurrentPawn();
			AFortPlayerControllerAthena *PC = (AFortPlayerControllerAthena *)Pawn->GetOwner();

			auto Entry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([Def](FFortItemEntry &Entry)
																				{ return Entry.ItemDefinition == Def; });
			Entry->Count -= 1;
			if (Entry->Count <= 0)
			{
				Inventory::Remove(PC, Entry->ItemGuid);
			}
			Inventory::ReplaceEntry(PC, *Entry);
		}
		return ApplyCostOG(GA, a2, a3, a4);
	}

	static void RestartDedicatedSession()
	{
		TerminateProcess(GetCurrentProcess(), 0);
	}

	static inline void (*SetVirtualJoystickVisibilityOG)(UObject *, FFrame &);
	static void CombinePickup(UObject *_this, FFrame &Stack)
	{
		auto Pickup = (AFortPickupAthena *)_this;

		Pickup->PickupLocationData.CombineTarget->PrimaryPickupItemEntry.Count += Pickup->PrimaryPickupItemEntry.Count;
		Pickup->PickupLocationData.CombineTarget->OnRep_PrimaryPickupItemEntry();
		Pickup->PickupLocationData.CombineTarget->ForceNetUpdate();

		Pickup->K2_DestroyActor();
	}

	static inline void (*StartAircraftPhaseOG)(AFortGameModeAthena *, char a2);
	static void StartAircraftPhase(AFortGameModeAthena *GM, char a2)
	{
		if (LateGame)
		{
			DestroyAll<AFortPickupAthena>();
			DestroyAll<AFortAthenaVehicle>();
		}
		StartAircraftPhaseOG(GM, a2);
		if (LateGame)
		{
			auto GS = AFortGameStateAthena::Get();
			GS->GamePhase = EAthenaGamePhase::SafeZones;
			GS->GamePhaseStep = EAthenaGamePhaseStep::StormHolding;
			GS->OnRep_GamePhase(EAthenaGamePhase::Aircraft);

			auto Bus = GS->Aircrafts[0];
			Bus->FlightInfo.FlightSpeed = 1000.f;
			auto &Loc = GM->SafeZoneLocations[rand() % (GM->SafeZoneLocations.Num() - 1)];
			while (Loc.X == 0 && Loc.Y == 0 && Loc.Z == 0)
				Loc = GM->SafeZoneLocations[rand() % (GM->SafeZoneLocations.Num() - 1)];
			Loc.Z = 17500.f;
			Bus->FlightInfo.FlightStartLocation = Loc.Quantize100();

			Bus->FlightInfo.TimeTillFlightEnd = 11.f;
			Bus->FlightInfo.TimeTillDropEnd = 11.f;
			Bus->FlightInfo.TimeTillDropStart = 1.f;
			Bus->FlightStartTime = UGameplayStatics::GetTimeSeconds(UWorld::Get()) + 1.f;
			Bus->FlightEndTime = UGameplayStatics::GetTimeSeconds(UWorld::Get()) + 11.f;
			GS->bAircraftIsLocked = false;
			GS->SafeZonesStartTime = UGameplayStatics::GetTimeSeconds(UWorld::Get());
		}
	}

	static inline void (*Athena_MedConsumable_TriggeredOriginal)(UObject *Context, FFrame &Stack, void *Ret);
	static void Athena_MedConsumable_TriggeredHook(UObject *Context, FFrame &Stack, void *Ret)
	{
		UGA_Athena_MedConsumable_Parent_C *Consumable = (UGA_Athena_MedConsumable_Parent_C *)Context;

		if (!Consumable || (!Consumable->HealsShields && !Consumable->HealsHealth) || !Consumable->PlayerPawn)
			return Athena_MedConsumable_TriggeredOriginal(Context, Stack, Ret);

		auto Handle = Consumable->PlayerPawn->AbilitySystemComponent->MakeEffectContext();
		FGameplayTag Tag{};
		static auto ShieldCue = UKismetStringLibrary::Conv_StringToName(L"GameplayCue.Shield.PotionConsumed");
		static auto HealthCue = UKismetStringLibrary::Conv_StringToName(L"GameplayCue.Athena.Health.HealUsed");
		Tag.TagName = Consumable->HealsShields ? ShieldCue : HealthCue;
		Consumable->PlayerPawn->AbilitySystemComponent->NetMulticast_InvokeGameplayCueAdded(Tag, FPredictionKey(), Handle);
		Consumable->PlayerPawn->AbilitySystemComponent->NetMulticast_InvokeGameplayCueExecuted(Tag, FPredictionKey(), Handle);

		return Athena_MedConsumable_TriggeredOriginal(Context, Stack, Ret);
	}

public:
	static inline void (*ReceiveHitOG)(APrj_Athena_HappyGhost_C *Object, FFrame &Stack);
	static void ReceiveHit(APrj_Athena_HappyGhost_C *Object, FFrame &Stack)
	{
		UPrimitiveComponent *Comp;
		AActor *Other;
		UPrimitiveComponent *OtherComp;
		bool bSelfMoved;
		FVector HitLocation;
		FVector HitNormal;
		FVector NormalImpulse;
		FHitResult Hit;
		Stack.StepCompiledIn(&Comp, true);
		Stack.StepCompiledIn(&Other, true);
		Stack.StepCompiledIn(&OtherComp, true);
		Stack.StepCompiledIn(&bSelfMoved, true);
		Stack.StepCompiledIn(&HitLocation, true);
		Stack.StepCompiledIn(&HitNormal, true);
		Stack.StepCompiledIn(&NormalImpulse, true);
		Stack.StepCompiledIn(&Hit, true);

		if (Other->bCanBeDamaged)
		{
			auto Projectile = Object->Cast<APrj_Athena_HappyGhost_C>();
			auto Weapon = Projectile->GetOwnerWeapon();
			auto PC = (AFortPlayerControllerAthena *)Projectile->GetOwnerPlayerController();
			auto Entry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([Weapon](FFortItemEntry &Entry)
																				{ return Entry.ItemGuid == Weapon->ItemEntryGuid; });
			Entry->LoadedAmmo--;
			if (Entry->LoadedAmmo <= 0)
			{
				Inventory::Remove(PC, Entry->ItemGuid);
			}
			Inventory::ReplaceEntry(PC, *Entry);
		}

		return ReceiveHitOG(Object, Stack);
	}

private:
	static float GetMaxTickRateHook()
	{
		return 30.f;
	}

public:
	static void HookFunctions()
	{
		Utils::Hook(WorldNetMode, GetNetMode);
		Utils::ExecHook(Utils::FindObject<UFunction>("/Script/FortniteGame.BuildingFoundation.SetDynamicFoundationTransform"), SetDynamicFoundationTransform, SetDynamicFoundationTransformOG);
		Utils::ExecHook(Utils::FindObject<UFunction>("/Script/FortniteGame.BuildingFoundation.SetDynamicFoundationEnabled"), SetDynamicFoundationEnabled, SetDynamicFoundationEnabledOG);
		Utils::Hook(StartNewSafeZonePhase, StartNewSafeZonePhaseHook, StartNewSafeZonePhaseOG);
		Utils::Hook(ImageBase + 0x29bed80, RemoveGadget);
		Utils::Hook(ImageBase + 0x2f1be20, OnExploded, OnExplodedOG);
		Utils::Hook(ImageBase + 0x1b1b6e0, ApplyCost, ApplyCostOG);
		Utils::Hook(ImageBase + 0x275e3f0, RestartDedicatedSession);
		Utils::Hook(ImageBase + 0x4f50740, CombinePickup, SetVirtualJoystickVisibilityOG);
		Utils::Hook(ImageBase + 0x1ed5710, StartAircraftPhase, StartAircraftPhaseOG);
		Utils::Hook(GetMaxTickRate, GetMaxTickRateHook);
		Utils::ExecHook(Utils::FindObject<UFunction>("/Game/Athena/Items/Consumables/Parents/GA_Athena_MedConsumable_Parent.GA_Athena_MedConsumable_Parent_C.Triggered_4C02BFB04B18D9E79F84848FFE6D2C32"), Athena_MedConsumable_TriggeredHook, Athena_MedConsumable_TriggeredOriginal);
		Utils::NullCall(0x1e66e0f);
		Utils::NullCall(0x4a84bd9);
		Utils::NullCall(0x2921384);
		Utils::NullCall(0x1b1bd82);
		Utils::NullCall(0x1fa3ec3);
		Utils::NullCall(0x28f8ddc);
		// ExecHook(FindObject<UFunction>("/Game/Athena/Items/Consumables/HappyGhost/Prj_Athena_HappyGhost.Prj_Athena_HappyGhost_C.ReceiveHit"), ReceiveHit, ReceiveHitOG);

		Utils::PatchU32(ImageBase + 0x262d9e3, 0x2922d59);

		Utils::PatchByte(EncryptionPatch, 0x74);
		Utils::PatchByte(GameSessionPatch, 0x85);
		Utils::PatchByte(ImageBase + 0x2715ef7, 0x85);
		Utils::PatchByte(ImageBase + 0x2715ec0, 0x85);

		auto GSPatch = ImageBase + 0x1ec1718;
		for (int i = 0; i < 18; i++)
			Utils::PatchByte(GSPatch + i, 0x90);
		for (auto &NullFunc : NullFuncs)
			Utils::PatchByte(NullFunc, 0xC3);
		for (auto &RetTrueFunc : RetTrueFuncs)
			Utils::Hook(RetTrueFunc, RetTrue);
	}
};