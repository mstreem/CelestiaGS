#pragma once

class Globals
{
public:
	constexpr static bool bCreative = false;
	constexpr static string_view PlaylistName =
		"/Game/Athena/Playlists/Playlist_DefaultSolo.Playlist_DefaultSolo"; // Solo
	///Game/Athena/Playlists/Creative/Playlist_PlaygroundV2.Playlist_PlaygroundV2 Creative
	///Game/Athena/Playlists/Fritter/Playlist_Fritter_Low.Playlist_Fritter_Low Forgot
	///Game/Athena/Playlists/Polaris/Playlist_Polaris_Solo.Playlist_Polaris_Solo Forgot
	// "/Game/Athena/Playlists/Creative/Playlist_PlaygroundV2.Playlist_PlaygroundV2";
};