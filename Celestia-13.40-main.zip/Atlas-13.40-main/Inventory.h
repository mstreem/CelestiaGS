#pragma once
#include "pch.h"

class Inventory
{
public:
	static FFortRangedWeaponStats *GetStats(UFortWeaponItemDefinition *Def)
	{
		if (!Def || !Def->WeaponStatHandle.DataTable)
			return nullptr;

		auto StatsPP = Def->WeaponStatHandle.DataTable->Search([Def](FName &Key, uint8_t *Value)
															   { return Def->WeaponStatHandle.RowName == Key && Value; });

		return StatsPP ? *(FFortRangedWeaponStats **)StatsPP : nullptr;
	}

	static FFortItemEntry *MakeItemEntry(UFortWorldItemDefinition *ID, int32 Count, int32 Level)
	{
		FFortItemEntry *IE = new FFortItemEntry();

		IE->MostRecentArrayReplicationKey = -1;
		IE->ReplicationID = -1;
		IE->ReplicationKey = -1;

		IE->ItemDefinition = ID;
		IE->Count = Count;
		IE->LoadedAmmo = ID->IsA<UFortWeaponItemDefinition>() ? GetStats((UFortWeaponItemDefinition *)ID)->ClipSize : 0;
		IE->Durability = 1.f;
		IE->GameplayAbilitySpecHandle = FGameplayAbilitySpecHandle(-1);
		IE->ParentInventory.ObjectIndex = -1;
		IE->Level = Level;

		return IE;
	}

	static AFortPickupAthena *SpawnPickup(FVector Loc, FFortItemEntry &Entry, EFortPickupSourceTypeFlag SourceTypeFlag = EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource SpawnSource = EFortPickupSpawnSource::Unset, AFortPlayerPawn *Pawn = nullptr, int OverrideCount = -1, bool Toss = true)
	{
		if (!&Entry)
			return nullptr;
		static auto PetrolLauncher = Utils::FindObject<UFortWeaponRangedItemDefinition>("/Game/Athena/Items/Weapons/Prototype/WID_Launcher_Petrol.WID_Launcher_Petrol");
		if (Entry.ItemDefinition == PetrolLauncher)
		{
			static auto BGA = Utils::FindObject<UBlueprintGeneratedClass>("/Game/Athena/Items/Weapons/Prototype/PetrolPump/BGA_Petrol_Pickup.BGA_Petrol_Pickup_C");
			Utils::SpawnActor(BGA, Loc, {});
			return nullptr;
		}
		AFortPickupAthena *NewPickup = Utils::SpawnActor<AFortPickupAthena>(Loc, {});
		if (!NewPickup)
			return nullptr;
		NewPickup->bRandomRotation = true;
		((FVector * (*)(AFortPickup *, FFortItemEntry *, TArray<FFortItemEntry>, bool))(ImageBase + 0x262adc0))(NewPickup, &Entry, TArray<FFortItemEntry>(), false);
		NewPickup->PrimaryPickupItemEntry.Count = OverrideCount != -1 ? OverrideCount : Entry.Count;
		NewPickup->OnRep_PrimaryPickupItemEntry();
		NewPickup->PawnWhoDroppedPickup = Pawn;

		auto Pickups = Utils::GetAll<AFortPickupAthena>();
		float MaxStackF;
		if (NewPickup->PrimaryPickupItemEntry.ItemDefinition->MaxStackSize.Curve.CurveTable)
			UDataTableFunctionLibrary::EvaluateCurveTableRow(NewPickup->PrimaryPickupItemEntry.ItemDefinition->MaxStackSize.Curve.CurveTable, NewPickup->PrimaryPickupItemEntry.ItemDefinition->MaxStackSize.Curve.RowName, 0.f, nullptr, &MaxStackF, FString());
		else
			MaxStackF = NewPickup->PrimaryPickupItemEntry.ItemDefinition->MaxStackSize.Value;
		auto MaxStack = (int32)MaxStackF;
		for (auto &Pickup : Pickups)
		{
			if (Pickup->PrimaryPickupItemEntry.ItemDefinition == Entry.ItemDefinition && Pickup->PrimaryPickupItemEntry.ItemDefinition->IsStackable() && Pickup->PrimaryPickupItemEntry.Count < MaxStack && Pickup->GetDistanceTo(NewPickup) <= 500 && NewPickup != Pickup)
			{
				NewPickup->PickupLocationData.CombineTarget = Pickup;
				break;
			}
		}
		Pickups.Free();
		if (NewPickup->PickupLocationData.CombineTarget)
		{
			NewPickup->PickupLocationData.LootInitialPosition = Loc.Quantize10();
			NewPickup->PickupLocationData.LootFinalPosition = NewPickup->PickupLocationData.CombineTarget->K2_GetActorLocation().Quantize10();
			NewPickup->PickupLocationData.FlyTime = NewPickup->PickupLocationData.CombineTarget->GetDistanceTo(NewPickup) / 1000;
			NewPickup->PickupLocationData.ItemOwner = Pawn;
			NewPickup->PickupLocationData.FinalTossRestLocation = NewPickup->PickupLocationData.CombineTarget->K2_GetActorLocation().Quantize10();
			NewPickup->OnRep_PickupLocationData();
		}
		else
		{
			NewPickup->TossPickup(Loc, Pawn, -1, Toss, true, SourceTypeFlag, SpawnSource);
			NewPickup->bTossedFromContainer = SpawnSource == EFortPickupSpawnSource::Chest || SpawnSource == EFortPickupSpawnSource::AmmoBox;
			if (NewPickup->bTossedFromContainer)
				NewPickup->OnRep_TossedFromContainer();
		}

		return NewPickup;
	}

	static AFortPickupAthena *SpawnPickup(ABuildingContainer *Container, FFortItemEntry &Entry, EFortPickupSourceTypeFlag SourceTypeFlag = EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource SpawnSource = EFortPickupSpawnSource::Unset, AFortPlayerPawn *Pawn = nullptr, int OverrideCount = -1, bool Toss = true)
	{
		if (!&Entry)
			return nullptr;
		AFortPickupAthena *NewPickup = Utils::SpawnActor<AFortPickupAthena>(Container->K2_GetActorLocation() + Container->GetActorForwardVector() * Container->LootSpawnLocation_Athena.X + Container->GetActorRightVector() * Container->LootSpawnLocation_Athena.Y + Container->GetActorUpVector() * Container->LootSpawnLocation_Athena.Z, {});
		if (!NewPickup)
			return nullptr;
		NewPickup->bRandomRotation = true;
		((FVector * (*)(AFortPickup *, FFortItemEntry *, TArray<FFortItemEntry>, bool))(ImageBase + 0x262adc0))(NewPickup, &Entry, TArray<FFortItemEntry>(), false);
		NewPickup->PrimaryPickupItemEntry.Count = OverrideCount != -1 ? OverrideCount : Entry.Count;
		NewPickup->OnRep_PrimaryPickupItemEntry();
		NewPickup->PawnWhoDroppedPickup = Pawn;

		UFortKismetLibrary::TossPickupFromContainer(UWorld::Get(), Container, NewPickup, 1, 0, Container->LootTossConeHalfAngle_Athena, Container->LootTossDirection_Athena, Container->LootTossSpeed_Athena, false);
		NewPickup->bTossedFromContainer = true;
		if (NewPickup->bTossedFromContainer)
			NewPickup->OnRep_TossedFromContainer();

		return NewPickup;
	}

	static AFortPickupAthena *SpawnPickup(FVector Loc, UFortItemDefinition *Def, int Count, int LoadedAmmo, EFortPickupSourceTypeFlag SourceTypeFlag = EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource SpawnSource = EFortPickupSpawnSource::Unset, AFortPlayerPawn *Pawn = nullptr, bool Toss = true)
	{
		auto entry = MakeItemEntry((UFortWorldItemDefinition *)Def, Count, 0);

		return SpawnPickup(Loc, *entry, SourceTypeFlag, SpawnSource, Pawn, Count, Toss);
	}

	static void TriggerInventoryUpdate(AFortPlayerController *PC, FFortItemEntry *Entry)
	{
		AFortInventory *Inventory;
		if (auto Bot = PC->Cast<AFortAthenaAIBotController>())
		{
			Inventory = Bot->Inventory;
		}
		else
		{
			Inventory = PC->WorldInventory;
		}
		if (!PC)
			return;
		Inventory->bRequiresLocalUpdate = true;
		Inventory->HandleInventoryLocalUpdate();

		return Entry ? Inventory->Inventory.MarkItemDirty(*Entry) : Inventory->Inventory.MarkArrayDirty();
	}

	static UFortWorldItem *GiveItem(AFortPlayerController *PC, UFortItemDefinition *Def, int Count = 1, int LoadedAmmo = 0, int Level = 0, bool ShowPickupNoti = true, bool updateInventory = true)
	{
		if (!PC || !Def)
			return nullptr;
		UFortWorldItem *Item = (UFortWorldItem *)Def->CreateTemporaryItemInstanceBP(Count, Level);
		Item->SetOwningControllerForTemporaryItem(PC);
		Item->ItemEntry.LoadedAmmo = LoadedAmmo;
		if (auto Weapon = Def->Cast<UFortWeaponItemDefinition>())
		{
			auto Stats = GetStats(Weapon);
			if (Weapon->bUsesPhantomReserveAmmo)
				Item->ItemEntry.PhantomReserveAmmo = Stats->InitialClips - Stats->ClipSize;
		}

		if (Def->IsA<UFortAmmoItemDefinition>() || Def->IsA<UFortResourceItemDefinition>())
		{
			FFortItemEntryStateValue Value{};
			Value.IntValue = ShowPickupNoti;
			Value.StateType = EFortItemEntryState::ShouldShowItemToast;
			Item->ItemEntry.StateValues.Add(Value);
		}

		auto IE = PC->WorldInventory->Inventory.ReplicatedEntries.Add(Item->ItemEntry);
		auto II = PC->WorldInventory->Inventory.ItemInstances.Add(Item);

		if (updateInventory)
			TriggerInventoryUpdate(PC, &Item->ItemEntry);
		return Item;
	}

	static UFortWorldItem *GiveItem(AFortPlayerController *PC, FFortItemEntry entry, int Count = -1, bool ShowPickupNoti = true, bool updateInventory = true)
	{
		if (Count == -1)
			Count = entry.Count;
		return GiveItem(PC, entry.ItemDefinition, Count, entry.LoadedAmmo, entry.Level, ShowPickupNoti, updateInventory);
	}

	static void ReplaceEntry(AFortPlayerController *PC, FFortItemEntry &Entry)
	{
		FFortItemList *Inventory;
		if (auto Bot = PC->Cast<AFortAthenaAIBotController>())
		{
			Inventory = &Bot->Inventory->Inventory;
		}
		else
		{
			Inventory = &PC->WorldInventory->Inventory;
		}
		if (!PC)
			return;
		auto ent = Inventory->ItemInstances.Search([Entry](UFortWorldItem *item)
												   { return item->ItemEntry.ItemGuid == Entry.ItemGuid; });
		if (!ent)
			return;
		(*ent)->ItemEntry = Entry;

		TriggerInventoryUpdate(PC, &Entry);
	}

	static EFortQuickBars GetQuickbar(UFortItemDefinition *Def)
	{
		static auto DisguiseAlter = Utils::FindObject<UFortGadgetItemDefinition>("/Game/Athena/Items/EnvironmentalItems/HidingProps/Props/PhantomBooth/AGID_Disguise_Alter.AGID_Disguise_Alter");
		static auto DisguiseEgo = Utils::FindObject<UFortGadgetItemDefinition>("/Game/Athena/Items/EnvironmentalItems/HidingProps/Props/PhantomBooth/AGID_Disguise_Ego.AGID_Disguise_Ego");
		static auto DisguiseScrapyard = Utils::FindObject<UFortGadgetItemDefinition>("/Game/Athena/Items/EnvironmentalItems/HidingProps/Props/PhantomBooth/AGID_Disguise_Scrapyard.AGID_Disguise_Scrapyard");
		return Def->IsA<UFortWeaponMeleeItemDefinition>() || Def->IsA<UFortResourceItemDefinition>() || Def->IsA<UFortAmmoItemDefinition>() || Def->IsA<UFortTrapItemDefinition>() || Def->IsA<UFortBuildingItemDefinition>() || Def->IsA<UFortEditToolItemDefinition>() || Def == DisguiseAlter || Def == DisguiseEgo || Def == DisguiseScrapyard ? EFortQuickBars::Secondary : EFortQuickBars::Primary;
	}

	static void SwapEntry(AFortPlayerController *PC, FFortItemEntry &Entry, FFortItemEntry &NewEntry)
	{
		if (!PC)
			return;
		auto ent = PC->WorldInventory->Inventory.ItemInstances.Search([Entry](UFortWorldItem *item)
																	  { return item->ItemEntry.ItemGuid == Entry.ItemGuid; });
		auto ent2 = PC->WorldInventory->Inventory.ReplicatedEntries.Search([Entry](FFortItemEntry &item)
																		   { return item.ItemGuid == Entry.ItemGuid; });
		if (!ent || !ent2)
			return;
		(*ent)->ItemEntry = NewEntry;
		*ent2 = NewEntry;

		TriggerInventoryUpdate(PC, &NewEntry);
		PC->ServerExecuteInventoryItem(NewEntry.ItemGuid);
		PC->ClientEquipItem(NewEntry.ItemGuid, true);
	}

	static void Remove(AFortPlayerController *PC, FGuid Guid)
	{
		FFortItemList *Inventory;
		if (auto Bot = PC->Cast<AFortAthenaAIBotController>())
		{
			Inventory = &Bot->Inventory->Inventory;
		}
		else
		{
			Inventory = &PC->WorldInventory->Inventory;
		}
		if (!PC)
			return;
		auto entry = Inventory->ReplicatedEntries.SearchIndex([Guid](FFortItemEntry &entry)
															  { return entry.ItemGuid == Guid; });
		if (entry != -1)
			Inventory->ReplicatedEntries.Remove(entry);
		auto item = Inventory->ItemInstances.SearchIndex([Guid](UFortWorldItem *entry)
														 { return entry->ItemEntry.ItemGuid == Guid; });
		if (item != -1)
			Inventory->ItemInstances.Remove(item);

		TriggerInventoryUpdate(PC, nullptr);
	}

	static void AddMore(AFortPlayerControllerAthena *PC, FFortItemEntry &Entry, int Count, bool ShowPickupNoti = true)
	{
		if (Entry.ItemDefinition->IsA<UFortAmmoItemDefinition>() || Entry.ItemDefinition->IsA<UFortResourceItemDefinition>())
		{
			auto State = Entry.StateValues.Search([](FFortItemEntryStateValue &Value)
												  { return Value.StateType == EFortItemEntryState::ShouldShowItemToast; });
			State->IntValue = ShowPickupNoti;
		}
		float MaxStackF;
		if (Entry.ItemDefinition->MaxStackSize.Curve.CurveTable)
			UDataTableFunctionLibrary::EvaluateCurveTableRow(Entry.ItemDefinition->MaxStackSize.Curve.CurveTable, Entry.ItemDefinition->MaxStackSize.Curve.RowName, 0.f, nullptr, &MaxStackF, FString());
		else
			MaxStackF = Entry.ItemDefinition->MaxStackSize.Value;
		auto MaxStack = (int32)MaxStackF;
		Entry.Count += Count;
		if (Entry.Count > MaxStack)
		{
			SpawnPickup(PC->Pawn->K2_GetActorLocation(), Entry.ItemDefinition, Entry.Count - MaxStack, 0, EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource::Unset, PC->MyFortPawn);
			Entry.Count = MaxStack;
		}
		ReplaceEntry(PC, Entry);
	}
};